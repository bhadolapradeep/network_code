# multinet/utils/data_utils.py

import networkx as nx
from typing import Dict, Union
import pandas as pd
import numpy as np

def assign_node_sectors(graph: nx.Graph, sector_mapping: Dict[str, str], sector_attribute: str = 'sector') -> None:
    """Assign a sector attribute to each node in the graph.

    This function modifies the input graph in-place by adding a node attribute
    based on a provided mapping dictionary.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph to which attributes will be added. The graph is
        modified in-place.
    sector_mapping : Dict[str, str]
        A dictionary where keys are node identifiers (matching nodes in the
        graph) and values are the corresponding sector labels (e.g., strings).
    sector_attribute : str, optional
        The name of the node attribute to store the sector labels, 
        by default 'sector'.

    Returns
    -------
    None
        This function does not return anything; it modifies the graph directly.

    Examples
    --------
    >>> import networkx as nx
    >>> G = nx.Graph()
    >>> G.add_nodes_from(['A', 'B', 'C'])
    >>> sector_map = {'A': 'Finance', 'B': 'Finance', 'C': 'Tech'}
    >>> assign_node_sectors(G, sector_map)
    >>> print(G.nodes['A']['sector'])
    Finance
    """
    nx.set_node_attributes(graph, sector_mapping, name=sector_attribute)

def zscore_normalization(df: pd.DataFrame) -> pd.DataFrame:
    """Standardize multivariate time-series data using Z-score normalization.

    Transforms the data such that each column has a mean of 0 and a standard
    deviation of 1. This is a critical preprocessing step for correlation-based
    network construction to ensure all variables are on the same scale.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame where rows represent time steps and columns represent
        variables (nodes).

    Returns
    -------
    pd.DataFrame
        A DataFrame with the same shape/index as the input, containing the
        standardized values.

    Notes
    -----
    The transformation is calculated as:
    .. math:: z = \\frac{x - \\mu}{\\sigma}

    Constant columns (where standard deviation is 0) are centered to 0
    but not scaled, avoiding division by zero errors.
    """
    if df.empty:
        return df

    # 1. Calculate Mean and Standard Deviation per column
    # We use numeric_only=True to ensure we don't crash on accidental non-numeric metadata
    means = df.mean(numeric_only=True)
    
    # Using ddof=1 (Delta Degrees of Freedom) for unbiased sample standard deviation
    stds = df.std(numeric_only=True, ddof=1)
    
    # 2. Handle zero-variance columns
    # If a column is constant, std is 0. Division by zero yields NaN/Inf.
    # We replace 0 with 1 in the divisor. Result will be (x - mean) / 1 = 0 (since x == mean).
    stds = stds.replace(0, 1.0)
    
    # 3. Perform Transformation
    # Pandas aligns indices automatically, so this safely broadcasts
    df_z = (df - means) / stds
    
    return df_z

def apply_fisher_z(
    data: Union[np.ndarray, pd.DataFrame], 
    epsilon: float = 1e-7
) -> Union[np.ndarray, pd.DataFrame]:
    """Apply the Fisher Z-transformation (arctanh) to correlation data.

    This transformation maps the bounded interval (-1, 1) to the real line 
    (-inf, inf). It is commonly used to stabilize variance and normalize the 
    distribution of correlation coefficients for statistical testing.

    Parameters
    ----------
    data : Union[np.ndarray, pd.DataFrame]
        Input array or DataFrame of correlation coefficients.
    epsilon : float, optional
        Small buffer to clip values away from exactly -1 or 1 to avoid 
        infinity, by default 1e-7.

    Returns
    -------
    Union[np.ndarray, pd.DataFrame]
        The Z-transformed data. Preserves input type and structure (if DataFrame).
        
    Notes
    -----
    Formula: :math:`z = \\text{arctanh}(r) = \\frac{1}{2} \\ln\\left(\\frac{1+r}{1-r}\\right)`
    """
    # 1. Handle Pandas DataFrame (Preserve Metadata)
    if isinstance(data, pd.DataFrame):
        # Recursively call function on the numpy array values
        z_values = apply_fisher_z(data.values, epsilon)
        return pd.DataFrame(z_values, index=data.index, columns=data.columns)

    # 2. Handle NumPy Array
    # Clip to (-1 + eps, 1 - eps) to prevent infinity/NaNs from log(0)
    # 1e-7 allows correlations up to 0.9999999
    clipped_data = np.clip(data, -1.0 + epsilon, 1.0 - epsilon)
    
    return np.arctanh(clipped_data)


def inverse_fisher_z(
    z_data: Union[np.ndarray, pd.DataFrame]
) -> Union[np.ndarray, pd.DataFrame]:
    """Apply the Inverse Fisher Z-transformation (tanh).

    Converts Z-scores back to correlation coefficients in the range (-1, 1).

    Parameters
    ----------
    z_data : Union[np.ndarray, pd.DataFrame]
        Input array or DataFrame of Z-scores.

    Returns
    -------
    Union[np.ndarray, pd.DataFrame]
        The reconstructed correlation coefficients.
    
    Notes
    -----
    Formula: :math:`r = \\tanh(z) = \\frac{e^{2z} - 1}{e^{2z} + 1}`
    """
    # 1. Handle Pandas DataFrame
    if isinstance(z_data, pd.DataFrame):
        r_values = inverse_fisher_z(z_data.values)
        return pd.DataFrame(r_values, index=z_data.index, columns=z_data.columns)

    # 2. Handle NumPy Array
    return np.tanh(z_data)