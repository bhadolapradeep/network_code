# multinetlib/analysis/network_properties.py

import networkx as nx
import numpy as np
from typing import Dict, Any
from .node_properties import detect_core_periphery

def calculate_network_properties(graph: nx.Graph) -> Dict[str, Any]:
    """Compute a comprehensive set of global properties for a network.

    Calculates various metrics that describe the overall structure and topology
    of the graph, such as density, clustering, and path lengths.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph to analyze.

    Returns
    -------
    Dict[str, Any]
        A dictionary where keys are property names (e.g., 'density') and
        values are the calculated metrics. Returns a minimal dictionary if
        the graph is empty.
    """
    if graph.number_of_nodes() == 0:
        return {'nodes': 0, 'edges': 0, 'density': 0.0}
        
    properties = {
        'nodes': graph.number_of_nodes(),
        'edges': graph.number_of_edges(),
        'density': nx.density(graph),
        'is_connected': nx.is_connected(graph),
        'num_components': nx.number_connected_components(graph),
        'avg_clustering': nx.average_clustering(graph),
        'global_efficiency': nx.global_efficiency(graph),
    }

    # Assortativity is undefined if all nodes have the same degree
    degrees = [d for n, d in graph.degree()]
    if np.std(degrees) == 0:
        properties['assortativity'] = np.nan
    else:
        properties['assortativity'] = nx.degree_assortativity_coefficient(graph)

    # Path-based properties are calculated on the Largest Connected Component (LCC)
    if properties['is_connected']:
        lcc = graph
    else:
        lcc_nodes = max(nx.connected_components(graph), key=len, default=set())
        lcc = graph.subgraph(lcc_nodes).copy() if lcc_nodes else graph.copy()

    if lcc.number_of_nodes() > 1:
        properties['avg_shortest_path_length'] = nx.average_shortest_path_length(lcc)
        properties['diameter'] = nx.diameter(lcc)
    else:
        properties['avg_shortest_path_length'] = 0
        properties['diameter'] = 0
        
    return properties

def calculate_network_coreness(graph: nx.Graph, core_quantile: float = 0.8) -> float:
    """Calculate the overall coreness of a network.

    This function quantifies the strength of a network's core-periphery
    structure. It defines a 'core' and a 'periphery' based on node degree
    centrality and then calculates the difference between their internal network
    densities. A high positive score indicates a well-defined structure where
    core nodes are densely connected to each other while periphery nodes are sparsely
    connected.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph to analyze.
    core_quantile : float, optional
        The degree centrality quantile used to classify nodes as core. Nodes
        with a degree in this quantile or higher are considered 'core'.
        Must be between 0 and 1. Defaults to 0.8.

    Returns
    -------
    float
        The network coreness score, calculated as `(core_density - periphery_density)`.
        Returns 0.0 if the network is too small or if a core/periphery
        cannot be meaningfully separated.

    See Also
    --------
    detect_core_periphery : The function used to classify individual nodes.

    Examples
    --------
    >>> import networkx as nx
    >>> # Create a barbell graph which has a clear core-periphery structure
    >>> # (two dense clusters connected by a path)
    >>> G = nx.barbell_graph(5, 2)
    >>> coreness = calculate_network_coreness(G)
    >>> # We expect a high positive coreness value
    >>> print(f"{coreness > 0.5}")
    True
    """
    if graph.number_of_nodes() < 3:
        return 0.0

    node_assignments = detect_core_periphery(graph, core_quantile)
    core_nodes = [node for node, assignment in node_assignments.items() if assignment == 1]
    periphery_nodes = [node for node, assignment in node_assignments.items() if assignment == 0]

    if not core_nodes or not periphery_nodes:
        # This can happen in very regular or small graphs
        return 0.0

    # Ensure subgraphs are not empty before calculating density
    core_subgraph = graph.subgraph(core_nodes)
    periphery_subgraph = graph.subgraph(periphery_nodes)

    core_density = nx.density(core_subgraph) if core_subgraph.number_of_nodes() > 1 else 0.0
    periphery_density = nx.density(periphery_subgraph) if periphery_subgraph.number_of_nodes() > 1 else 0.0

    return core_density - periphery_density