# multinetlib/analysis/node_properties.py

import pandas as pd
import networkx as nx
from typing import Dict

def calculate_node_properties(graph: nx.Graph) -> pd.DataFrame:
    """Compute a comprehensive set of properties for each node.

    This function calculates various centrality and structural metrics for
    every node in the network and returns them in a convenient DataFrame.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph to analyze.

    Returns
    -------
    pd.DataFrame
        A DataFrame where the index contains node labels and each column
        represents a calculated property (e.g., 'degree_centrality').
        Returns an empty DataFrame if the graph is empty.
    """
    if graph.number_of_nodes() == 0:
        return pd.DataFrame()

    properties = {
        'degree_centrality': nx.degree_centrality(graph),
        'betweenness_centrality': nx.betweenness_centrality(graph),
        'closeness_centrality': nx.closeness_centrality(graph),
        'local_clustering_coefficient': nx.clustering(graph),
        'k_core_number': nx.core_number(graph),
    }

    # Handle eigenvector centrality convergence issues
    try:
        properties['eigenvector_centrality'] = nx.eigenvector_centrality(graph, max_iter=500, tol=1e-05)
    except (nx.NetworkXError, nx.PowerIterationFailedConvergence):
        properties['eigenvector_centrality'] = {node: 0.0 for node in graph.nodes()}
    
    return pd.DataFrame(properties)

def detect_core_periphery(graph: nx.Graph, core_quantile: float = 0.8) -> Dict[str, int]:
    """Detect core and periphery nodes based on degree centrality.

    Nodes are classified as 'core' (1) if their degree is in the top
    quantile, and 'periphery' (0) otherwise.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph to analyze.
    core_quantile : float, optional
        The quantile of degree centrality above which a node is considered
        part of the core, by default 0.8.

    Returns
    -------
    Dict[str, int]
        A dictionary mapping each node to its assignment: 1 for core,
        0 for periphery.
    """
    if not (0 < core_quantile < 1):
        raise ValueError("core_quantile must be between 0 and 1.")
    if graph.number_of_nodes() == 0:
        return {}

    degrees = dict(graph.degree())
    if not degrees:
        return {}

    # Find the degree value at the specified quantile
    threshold_degree = pd.Series(degrees).quantile(core_quantile)
    
    node_assignments = {}
    for node, degree in degrees.items():
        node_assignments[node] = 1 if degree >= threshold_degree else 0
            
    return node_assignments