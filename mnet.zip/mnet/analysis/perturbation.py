# multinetlib/analysis/perturbation.py

import pandas as pd
import networkx as nx

def analyze_node_perturbation(graph: nx.Graph) -> pd.DataFrame:
    """Perform a node perturbation analysis on the largest connected component.

    This function iteratively removes each node from the graph's largest
    connected component (LCC) and calculates the resulting impact on network
    properties, such as the LCC size and global efficiency. This is a common
    method to identify critical nodes whose removal most significantly
    fragments or weakens the network.

    Parameters
    ----------
    graph : nx.Graph
        The original, unperturbed NetworkX graph. The analysis will be
        performed on its largest connected component.

    Returns
    -------
    pd.DataFrame
        A DataFrame where the index is the removed node's label and columns
        report the relative impact on network properties (e.g.,
        'efficiency_impact'). Values are normalized to represent the
        fractional change from the initial state.
    """
    # Ensure analysis is on a connected graph for meaningful results
    if not nx.is_connected(graph):
        lcc_nodes = max(nx.connected_components(graph), key=len, default=set())
        if not lcc_nodes:
            return pd.DataFrame()
        graph = graph.subgraph(lcc_nodes).copy()

    initial_properties = {
        'lcc_size': graph.number_of_nodes(),
        'efficiency': nx.global_efficiency(graph)
    }

    results = []
    nodes_to_iterate = list(graph.nodes()) # Create a copy to iterate over
    for node_to_remove in nodes_to_iterate:
        perturbed_graph = graph.copy()
        perturbed_graph.remove_node(node_to_remove)
        impact = {'node': node_to_remove}

        if perturbed_graph.number_of_nodes() > 0:
            pert_lcc_nodes = max(nx.connected_components(perturbed_graph), key=len, default=set())
            pert_lcc = perturbed_graph.subgraph(pert_lcc_nodes)
            
            perturbed_properties = {
                'lcc_size': pert_lcc.number_of_nodes(),
                'efficiency': nx.global_efficiency(pert_lcc) if pert_lcc.number_of_nodes() > 0 else 0
            }
            # Normalize the impact
            impact['lcc_impact'] = (initial_properties['lcc_size'] - perturbed_properties['lcc_size']) / initial_properties['lcc_size']
            if initial_properties['efficiency'] > 0:
                impact['efficiency_impact'] = (initial_properties['efficiency'] - perturbed_properties['efficiency']) / initial_properties['efficiency']
            else:
                 impact['efficiency_impact'] = 0.0
        else:
            # If removing the node empties the graph
            impact['lcc_impact'] = 1.0
            impact['efficiency_impact'] = 1.0

        results.append(impact)

    return pd.DataFrame(results).set_index('node')