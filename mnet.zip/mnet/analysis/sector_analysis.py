# multinetlib/analysis/sector_analysis.py

import pandas as pd
import networkx as nx
from collections import defaultdict

def calculate_sector_connectedness_matrix(graph: nx.Graph, sector_attribute: str = 'sector') -> pd.DataFrame:
    """Calculate a matrix of intra- and inter-sector connectedness.

    This function quantifies the connection strength both within and between
    predefined groups of nodes (sectors). Connectedness is defined as the sum
    of edge weights normalized by the number of all possible edges, providing
    a measure analogous to density.

    Parameters
    ----------
    graph : nx.Graph
        A weighted NetworkX graph. Nodes must have a sector attribute.
    sector_attribute : str, optional
        The name of the node attribute that holds the sector labels,
        by default 'sector'.

    Returns
    -------
    pd.DataFrame
        A symmetric DataFrame where both the index and columns are sector
        labels. Cell `(s1, s2)` contains the connectedness between sector `s1`
        and sector `s2`.

    Raises
    ------
    KeyError
        If the specified `sector_attribute` is not found on the nodes.
    """
    nodes_by_sector = defaultdict(list)
    try:
        for node, data in graph.nodes(data=True):
            nodes_by_sector[data[sector_attribute]].append(node)
    except KeyError:
        raise KeyError(f"Node attribute '{sector_attribute}' not found. "
                       "Ensure nodes have this attribute assigned.")

    sectors = sorted(nodes_by_sector.keys())
    conn_matrix = pd.DataFrame(0.0, index=sectors, columns=sectors)

    for i, s1 in enumerate(sectors):
        for j, s2 in enumerate(sectors):
            if i > j: continue  # Matrix is symmetric
            
            nodes1, nodes2 = nodes_by_sector[s1], nodes_by_sector[s2]
            
            if s1 == s2:  # Intra-sector connectedness
                subgraph = graph.subgraph(nodes1)
                weight_sum = subgraph.size(weight='weight')
                n = len(nodes1)
                # Max possible edges in a simple graph
                norm = n * (n - 1) / 2 if n > 1 else 1
                conn = weight_sum / norm if norm > 0 else 0
                conn_matrix.loc[s1, s1] = conn
            else:  # Inter-sector connectedness
                # Use edge_boundary to find edges between the two node sets
                edges = nx.edge_boundary(graph, nodes1, nodes2, data='weight', default=1)
                weight_sum = sum(w for _, _, w in edges)
                # Max possible edges between two sets of nodes
                norm = len(nodes1) * len(nodes2)
                conn = weight_sum / norm if norm > 0 else 0
                conn_matrix.loc[s1, s2] = conn
                conn_matrix.loc[s2, s1] = conn
                
    return conn_matrix