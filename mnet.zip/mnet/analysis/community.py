# multinetlib/analysis/community.py

import networkx as nx
from networkx.algorithms import community
from typing import Dict, Any

def detect_communities(graph: nx.Graph, method: str = 'louvain', **kwargs: Any) -> Dict[str, int]:
    """Detect communities in a network using a specified algorithm.

    This function serves as a wrapper for various community detection
    algorithms available in NetworkX.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph to analyze.
    method : str, optional
        The algorithm to use for community detection. Supported options are
        'louvain' (default) and 'girvan_newman'.
    **kwargs : Any
        Additional keyword arguments to be passed to the underlying NetworkX
        community detection function (e.g., `resolution` for Louvain).

    Returns
    -------
    Dict[str, int]
        A dictionary mapping each node to an integer representing its
        community ID.

    Raises
    ------
    ValueError
        If an unsupported `method` is specified.

    Examples
    --------
    >>> import networkx as nx
    >>> G = nx.karate_club_graph()
    >>> communities = detect_communities(G, method='louvain')
    >>> print(communities[0])  # Print the community of node 0
    0
    """
    if method == 'louvain':
        # The Louvain algorithm returns a list of sets (communities)
        communities_sets = community.louvain_communities(graph, **kwargs)
    elif method == 'girvan_newman':
        # Girvan-Newman returns a generator; we take the first level of division
        comp = community.girvan_newman(graph)
        communities_sets = next(comp)
    else:
        raise ValueError(f"Unsupported community detection method: {method}")

    node_community_map = {}
    for i, comm_set in enumerate(communities_sets):
        for node in comm_set:
            node_community_map[node] = i
            
    return node_community_map