import numpy as np
import pandas as pd
from typing import Tuple, List, Optional, Union
from scipy.stats import entropy

def calculate_rmt_bounds(L: int, N: int, sigma: float = 1.0) -> Tuple[float, float]:
    """Calculate the Marchenko-Pastur (RMT) bounds for eigenvalues.
    
    Parameters
    ----------
    L : int
        Size of the time series (number of observations/rows).
    N : int
        Number of variables (number of assets/nodes/columns).
    sigma : float, optional
        Standard deviation of the underlying process, by default 1.0.

    Returns
    -------
    Tuple[float, float]
        (lambda_minus, lambda_plus) representing the theoretical noise bounds.
    """
    if L <= 0 or N <= 0:
        raise ValueError("L and N must be positive integers.")

    q = L / N
    lambda_plus = (sigma**2) * (1 + np.sqrt(1/q))**2
    lambda_minus = (sigma**2) * (1 - np.sqrt(1/q))**2
    return max(0.0, lambda_minus), lambda_plus


def compute_spectral_properties(
    data: Union[np.ndarray, pd.DataFrame], 
    zero_cutoff: float = 1e-12
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Perform eigen-decomposition and extract correlation distribution.

    This function calculates the correlation matrix from time-series data,
    decomposes it into eigenvalues and eigenvectors, and extracts the
    off-diagonal correlation coefficients.

    Parameters
    ----------
    data : Union[np.ndarray, pd.DataFrame]
        The multivariate time series data. 
        Shape should be (Time, Variables/Nodes).
    zero_cutoff : float, optional
        Threshold below which eigenvalues are considered zero (due to 
        numerical precision), by default 1e-12.

    Returns
    -------
    evals : np.ndarray
        Sorted eigenvalues in descending order (Largest -> Smallest).
    evecs : np.ndarray
        Corresponding eigenvectors (columns match the sorted eigenvalues).
    off_diag : np.ndarray
        A flat array of all off-diagonal correlation coefficients (upper 
        triangle), useful for plotting the distribution P(rho).

    Raises
    ------
    ValueError
        If the correlation matrix contains NaNs.
    """
    # 1. Input Standardization
    if isinstance(data, pd.DataFrame):
        matrix = data.values
    else:
        matrix = data

    # 2. Compute Correlation Matrix
    # rowvar=False implies rows are Time, columns are Variables
    corr_mat = np.corrcoef(matrix, rowvar=False)

    if np.isnan(corr_mat).any():
        raise ValueError(
            "Computed correlation matrix contains NaNs. "
            "Check input data for constant columns or missing values."
        )

    # 3. Eigen-decomposition
    # eigh is optimized for symmetric/Hermitian matrices (like correlation matrices)
    evals, evecs = np.linalg.eigh(corr_mat)

    # 4. Implement Zero Cut-off & Clean up
    evals[np.abs(evals) < zero_cutoff] = 0.0

    # 5. Sort in Descending Order (Largest eigenvalue first)
    # argsort gives ascending, so we reverse it [::-1]
    idx = evals.argsort()[::-1]
    evals = evals[idx]
    evecs = evecs[:, idx]

    # 6. Extract Off-diagonal values
    # k=1 excludes the main diagonal (which is always 1.0)
    N = corr_mat.shape[0]
    iu = np.triu_indices(N, k=1)
    off_diag = corr_mat[iu]

    return evals, evecs, off_diag

def compute_entropy_metrics(
    evecs: np.ndarray, 
    node_labels: Optional[List[str]] = None
) -> Tuple[pd.DataFrame, pd.Series]:
    """Calculate the Normalized Shannon Entropy for each eigenvector.

    This metric quantifies the localization of the eigenvectors.
    - High entropy (~1.0) implies the vector is delocalized (many nodes participate).
    - Low entropy (~0.0) implies the vector is localized (driven by few nodes).

    Parameters
    ----------
    evecs : np.ndarray
        Matrix of eigenvectors (Columns are vectors, Rows are nodes).
        Typically obtained from `compute_spectral_properties`.
    node_labels : List[str], optional
        A list of node names to index the probability DataFrame.
        If None, generic indices 'node_0', 'node_1'... are used.

    Returns
    -------
    prob_components : pd.DataFrame
        The squared components (|v_ij|^2) representing the contribution
        probability of each node i to vector j.
    entropies : pd.Series
        The normalized Shannon entropy for each eigenvector.
        Index matches the columns of `prob_components`.

    Notes
    -----
    The Normalized Entropy $H_j$ is calculated as:
    .. math:: H_j = \\frac{- \\sum_{i=1}^{N} p_{ij} \\ln(p_{ij})}{\\ln(N)}
    where $p_{ij} = |v_{ij}|^2$.
    """
    N, num_vectors = evecs.shape

    # 1. Calculate probability components: p_ij = |v_ij|^2
    # This represents the weight of node i in eigenvector j.
    # We use abs() to handle potential complex numbers, though corr matrix evecs are real.
    prob_components = np.square(np.abs(evecs))

    # 2. Calculate Shannon Entropy
    # scipy.stats.entropy handles p=0 automatically and efficiently.
    # We compute along axis=0 (down the rows for each column vector).
    # base=np.e ensures Natural Log.
    raw_entropy = entropy(prob_components, base=np.e, axis=0)

    # 3. Normalize by ln(N)
    # This scales the result between 0 (localized) and 1 (fully delocalized/uniform).
    norm_entropy = raw_entropy / np.log(N)

    # 4. Format Outputs
    # Create column names for vectors
    vec_names = [f"eig_vec_{i+1}" for i in range(num_vectors)]
    
    # Handle Node Labels
    if node_labels is None:
        index_names = [f"node_{i}" for i in range(N)]
    else:
        if len(node_labels) != N:
            raise ValueError(f"Length of node_labels ({len(node_labels)}) must match rows in evecs ({N}).")
        index_names = node_labels

    # DataFrame for probabilities
    prob_df = pd.DataFrame(
        prob_components,
        index=index_names,
        columns=vec_names
    )

    # Series for Entropies
    entropy_series = pd.Series(
        norm_entropy,
        index=vec_names,
        name="normalized_entropy"
    )

    return prob_df, entropy_series