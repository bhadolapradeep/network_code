# multinetlib/network/construct.py

import pandas as pd
import numpy as np
import networkx as nx
from typing import Dict, Union

try:
    import planarity
except ImportError:
    planarity = None

def build_threshold_network(
    corr_df: pd.DataFrame, threshold: float, weighted: bool = True
) -> Union[nx.Graph, Dict[str, nx.Graph]]:
    """Build network(s) by applying a correlation threshold.

    This function constructs a graph by retaining edges where the absolute
    correlation value meets or exceeds a specified threshold. It can operate
    on a single correlation matrix or a tidy DataFrame containing multiple
    matrices stacked, distinguished by a 'layer' column.

    Parameters
    ----------
    corr_df : pd.DataFrame
        A DataFrame containing the correlation matrix.
        - For a single network, this should be an N x N matrix.
        - For multiple networks, it should be a tidy DataFrame with a 'layer'
          column and a 'node' column to be used as the index.
    threshold : float
        The absolute correlation value (between 0.0 and 1.0) above which
        an edge will be created.
    weighted : bool, optional
        If True (default), edges will have a 'weight' attribute equal to the
        correlation value. If False, the resulting graph will be unweighted.

    Returns
    -------
    Union[nx.Graph, Dict[str, nx.Graph]]
        - If `corr_df` represents a single matrix, returns a single NetworkX Graph.
        - If `corr_df` contains multiple layers, returns a dictionary where keys
          are layer names and values are the corresponding NetworkX Graphs.

    Raises
    ------
    ValueError
        If the threshold is not between 0 and 1.

    Examples
    --------
    >>> import pandas as pd
    >>> import networkx as nx
    >>> data = {'A': [1, 0.8, 0.1], 'B': [0.8, 1, 0.9], 'C': [0.1, 0.9, 1]}
    >>> corr_matrix = pd.DataFrame(data, index=['A', 'B', 'C'])
    >>> G = build_threshold_network(corr_matrix, threshold=0.85)
    >>> print(sorted(list(G.edges)))
    [('B', 'C')]
    """
    if not (0 <= threshold <= 1):
        raise ValueError("Threshold must be between 0 and 1.")

    def _create_graph(matrix: pd.DataFrame) -> nx.Graph:
        adj = matrix.copy()
        adj[np.abs(adj) < threshold] = 0
        np.fill_diagonal(adj.values, 0)
        if not weighted:
            adj[adj != 0] = 1.0
        G = nx.from_pandas_adjacency(adj)
        # Remove isolated nodes that may result from thresholding
        # G.remove_nodes_from(list(nx.isolates(G)))
        return G

    if 'layer' in corr_df.columns:
        graphs = {}
        # Assumes a tidy format with a 'node' column to be set as index
        for layer_name, group_df in corr_df.groupby('layer'):
            node_cols = [c for c in group_df.columns if c not in ['layer', 'node']]
            matrix = group_df.set_index('node')[node_cols]
            graphs[str(layer_name)] = _create_graph(matrix)
        return graphs
    else:
        return _create_graph(corr_df)


def build_mst_network(
    corr_df: pd.DataFrame,
) -> Union[nx.Graph, Dict[str, nx.Graph]]:
    """Build network(s) using a Minimum Spanning Tree (MST) filter.

    This function constructs a sparse, connected, and acyclic network by
    finding the MST from a correlation matrix. To work with correlations
    (where higher is better), it first converts the matrix into a distance
    matrix.

    Parameters
    ----------
    corr_df : pd.DataFrame
        A DataFrame containing the correlation matrix.
        - For a single network, this should be an N x N matrix.
        - For multiple networks, it should be a tidy DataFrame with a 'layer'
          column and a 'node' column.

    Returns
    -------
    Union[nx.Graph, Dict[str, nx.Graph]]
        A single NetworkX Graph or a dictionary of Graphs, filtered to
        contain only the edges of the MST.

    Notes
    -----
    The transformation from a correlation matrix `C` to a distance matrix `D`
    is done using the formula: D = sqrt(2 * (1 - C)). This maps high
    correlations to short distances, allowing a standard MST algorithm to find
    the strongest set of connections.
    """

    def _create_mst(matrix: pd.DataFrame) -> nx.Graph:
        # Convert correlation to distance: D = sqrt(2 * (1 - C))
        dist_matrix = np.sqrt(2 * (1 - matrix))
        np.fill_diagonal(dist_matrix.values, 0)
        g_full = nx.from_pandas_adjacency(dist_matrix)
        return nx.minimum_spanning_tree(g_full)

    if 'layer' in corr_df.columns:
        graphs = {}
        for layer_name, group_df in corr_df.groupby('layer'):
            node_cols = [c for c in group_df.columns if c not in ['layer', 'node']]
            matrix = group_df.set_index('node')[node_cols]
            graphs[str(layer_name)] = _create_mst(matrix)
        return graphs
    else:
        return _create_mst(corr_df)


def build_pmfg_network(
    corr_df: pd.DataFrame,
) -> Union[nx.Graph, Dict[str, nx.Graph]]:
    """Build network(s) using a Planar Maximally Filtered Graph (PMFG).

    Constructs a network that is both sparse and contains more information
    than an MST, such as cliques and hubs. The resulting graph has the maximum
    number of edges (3N - 6 for N > 2) while remaining planar.

    Parameters
    ----------
    corr_df : pd.DataFrame
        A DataFrame containing the correlation matrix. Can be a single N x N
        matrix or a tidy DataFrame with a 'layer' column.

    Returns
    -------
    Union[nx.Graph, Dict[str, nx.Graph]]
        The resulting PMFG as a NetworkX Graph or a dictionary of Graphs.

    Raises
    ------
    ImportError
        If the 'planarity' library is not installed. It is an optional
        dependency and can be installed with `pip install planarity`.

    Notes
    -----
    A PMFG is built by iteratively adding edges in descending order of
    correlation, only keeping an edge if it does not violate the planarity
    of the graph.
    """
    if planarity is None:
        raise ImportError(
            "The 'planarity' library is required for PMFG. "
            "Please run: pip install planarity"
        )

    def _create_pmfg(matrix: pd.DataFrame) -> nx.Graph:
        nodes = matrix.columns
        n = len(nodes)
        if n < 4:
            return nx.complete_graph(nodes)

        iupper = np.triu_indices(n, k=1)
        sorted_edges = sorted(
            zip(matrix.values[iupper], nodes[iupper[0]], nodes[iupper[1]]),
            key=lambda x: x[0],
            reverse=True,
        )

        g = nx.Graph()
        g.add_nodes_from(nodes)
        # A planar graph has at most 3N - 6 edges
        target_edges = 3 * (n - 2)
        edge_count = 0
        for weight, u, v in sorted_edges:
            g.add_edge(u, v, weight=weight)
            if not planarity.is_planar(g):
                g.remove_edge(u, v)
            else:
                edge_count += 1
            if edge_count == target_edges:
                break
        return g

    if 'layer' in corr_df.columns:
        graphs = {}
        for layer_name, group_df in corr_df.groupby('layer'):
            node_cols = [c for c in group_df.columns if c not in ['layer', 'node']]
            matrix = group_df.set_index('node')[node_cols]
            graphs[str(layer_name)] = _create_pmfg(matrix)
        return graphs
    else:
        return _create_pmfg(corr_df)