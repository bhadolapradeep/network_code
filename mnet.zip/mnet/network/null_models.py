# multinetlib/network/null_models.py

import pandas as pd
import numpy as np
import networkx as nx
from .construct import build_threshold_network
from .filtering import compute_spectral_properties, compute_entropy_metrics, calculate_rmt_bounds
from typing import Tuple, List, Optional, Dict, Any

def generate_shuffled_network(timeseries_df: pd.DataFrame, threshold: float, weighted: bool = True, seed: int = None) -> nx.Graph:
    """Generate a null network by shuffling time series columns.

    This method destroys temporal correlations while preserving the
    distribution of values within each time series. The resulting network
    serves as a null model for comparison against the real network.

    Parameters
    ----------
    timeseries_df : pd.DataFrame
        The original DataFrame of time series data (nodes are columns).
    threshold : float
        The correlation threshold to apply after shuffling.
    weighted : bool, optional
        Whether the resulting network should be weighted, by default True.
    seed : int, optional
        A seed for the random number generator for reproducibility,
        by default None.

    Returns
    -------
    nx.Graph
        A NetworkX graph generated from the shuffled data.
    """
    rng = np.random.default_rng(seed)
    shuffled_df = timeseries_df.copy()
    for col in shuffled_df.columns:
        rng.shuffle(shuffled_df[col].values)
    null_corr_matrix = shuffled_df.corr(numeric_only=True)
    return build_threshold_network(null_corr_matrix, threshold, weighted)

def generate_random_graph_model(original_graph: nx.Graph, seed: int = None) -> nx.Graph:
    """Generate a random graph with the same number of nodes and edges.

    This creates an Erdos-Renyi (G(n,m)) random graph that has the same
    number of nodes (n) and edges (m) as the original graph. It preserves
    basic density but not the degree distribution or other structures.

    Parameters
    ----------
    original_graph : nx.Graph
        The graph to model.
    seed : int, optional
        A seed for the random number generator, by default None.

    Returns
    -------
    nx.Graph
        The generated G(n,m) random graph.
    """
    n = original_graph.number_of_nodes()
    m = original_graph.number_of_edges()
    return nx.gnm_random_graph(n, m, seed=seed)

def generate_random_matrix_network(
    num_nodes: int, node_labels: list, threshold: float, weighted: bool = True, seed: int = None
) -> nx.Graph:
    """Generate a null network from a random correlation-like matrix.

    This function creates a benchmark network by first generating a random,
    symmetric matrix with a diagonal of 1s, mimicking a correlation matrix.
    It then builds a graph from this matrix using a given threshold. This
    serves as a null model where node count and link density can be matched,
    but all structural correlations are random.

    Parameters
    ----------
    num_nodes : int
        The number of nodes the generated network should have.
    node_labels : list
        A list of strings to be used as labels for the nodes. The length
        of this list must be equal to `num_nodes`.
    threshold : float
        The absolute correlation value (between 0.0 and 1.0) above which
        an edge will be created in the final network.
    weighted : bool, optional
        If True (default), edges will have a 'weight' attribute equal to the
        random correlation value. If False, the graph will be unweighted.
    seed : int, optional
        A seed for the random number generator to ensure reproducibility,
        by default None.

    Returns
    -------
    nx.Graph
        A NetworkX graph constructed from the random matrix.

    See Also
    --------
    generate_shuffled_network : Generate a null model by shuffling time series.
    build_threshold_network : The underlying function used to create the graph.

    Examples
    --------
    >>> import networkx as nx
    >>> labels = ['A', 'B', 'C']
    >>> G_rand = generate_random_matrix_network(
    ...     num_nodes=3,
    ...     node_labels=labels,
    ...     threshold=0.5,
    ...     seed=42
    ... )
    >>> print(G_rand.nodes())
    ['A', 'B', 'C']
    """
    rng = np.random.default_rng(seed)
    mat = rng.uniform(-1, 1, size=(num_nodes, num_nodes))
    mat = (mat + mat.T) / 2  # Make the matrix symmetric
    np.fill_diagonal(mat, 1.0)
    random_corr_matrix = pd.DataFrame(mat, index=node_labels, columns=node_labels)
    return build_threshold_network(random_corr_matrix, threshold, weighted)

def analyze_spectral_null_model(
    data: pd.DataFrame, 
    n_samples: int = 100, 
    seed: Optional[int] = None
) -> Dict[str, Any]:
    """Execute a Global Shuffle Null Model analysis for Random Matrix Theory (RMT).

    This function generates a distribution of spectral properties (eigenvalues,
    eigenvectors, entropy) based on randomized data. It destroys both temporal
    dependencies and cross-sectional correlations to simulate a "pure noise" system.

    Parameters
    ----------
    data : pd.DataFrame
        Input time-series data (Rows=Time, Cols=Nodes).
    n_samples : int, optional
        Number of randomized iterations to perform, by default 100.
    seed : int, optional
        Random seed for reproducibility, by default None.

    Returns
    -------
    Dict[str, Any]
        A dictionary containing the null model statistics:
        - 'eigenvalues': List[float] (All eigenvalues from all samples)
        - 'max_eigenvalues': List[float] (The largest eigenvalue from each sample)
        - 'off_diagonal_values': List[float] (All off-diag correlations from all samples)
        - 'avg_eigenvector_energy': pd.DataFrame (Average |v_ij|^2 across samples)
        - 'entropy_stats': pd.DataFrame (Mean and Std of entropy for each rank)
        - 'rmt_bounds': Tuple[float, float] (Theoretical lambda_minus, lambda_plus)

    Notes
    -----
    The results from this function are typically used to plot a histogram of
    "noise" eigenvalues overlaying the Marchenko-Pastur distribution .
    """
    rng = np.random.default_rng(seed)
    
    # 1. Setup Data Structures
    L, N = data.shape
    data_flat = data.values.flatten()
    
    # Pre-allocate lists for heavy data
    all_evals: List[float] = []
    max_evals: List[float] = []
    all_corrs: List[float] = []
    
    # Matrix to accumulate eigenvector energy (|v|^2) for averaging
    # Shape: (Nodes, Vectors) -> matches output of compute_entropy_metrics
    sum_sq_evecs = np.zeros((N, N)) 
    
    # Matrix to store entropy history: (Samples, Vectors)
    entropy_history = np.zeros((n_samples, N))

    # 2. Iterative Randomization
    for s in range(n_samples):
        # A. Global Shuffle: Destroys all structure
        shuffled_flat = rng.permutation(data_flat)
        shuffled_data = shuffled_flat.reshape(L, N)
        
        # B. Compute Spectral Properties
        evals, evecs, off_diag = compute_spectral_properties(shuffled_data)
        
        # C. Compute Entropy
        # We don't need node labels for the null model aggregation
        prob_df, sample_entropies = compute_entropy_metrics(evecs, node_labels=None)
        
        # D. Accumulate Results
        all_evals.extend(evals)
        max_evals.append(evals[0]) # Track largest eigenvalue of noise
        all_corrs.extend(off_diag)
        
        # Accumulate the raw probability matrix (numpy) for speed
        sum_sq_evecs += prob_df.values
        
        # Store entropy (Series -> Array)
        entropy_history[s, :] = sample_entropies.values

    # 3. Aggregation & Formatting
    
    # Average Square Eigenvectors (Energy)
    avg_sq_evecs = sum_sq_evecs / n_samples
    avg_comp_df = pd.DataFrame(
        avg_sq_evecs,
        index=data.columns, # Map back to original node names
        columns=[f"eig_vec_{i+1}" for i in range(N)]
    )

    # Entropy Statistics (Mean & Std Dev per eigenvector rank)
    entropy_stats_df = pd.DataFrame({
        'mean_entropy': np.mean(entropy_history, axis=0),
        'std_entropy': np.std(entropy_history, axis=0)
    }, index=[f"eig_vec_{i+1}" for i in range(N)])

    # Theoretical Bounds
    rmt_bounds = calculate_rmt_bounds(L, N)

    return {
        "off_diagonal_values": np.array(all_corrs), # Return as array for easier plotting
        "rmt_bounds": rmt_bounds,
        "eigenvalues": np.array(all_evals),
        "max_eigenvalues": np.array(max_evals),
        "avg_eigenvector_energy": avg_comp_df,
        "entropy_stats": entropy_stats_df
    }