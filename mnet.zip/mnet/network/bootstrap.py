# mnet/network/bootstrap.py

import numpy as np
import pandas as pd
from typing import Optional, Dict, Tuple
from tqdm import tqdm

class NullHypothesisSampler:
    """Performs bootstrap sampling to generate Null Model distributions.
    
    This class generates an ensemble of random networks by shuffling the
    time-series data. This destroys the temporal cross-correlations between
    nodes while preserving the marginal distribution of each node's values.
    
    It allows you to determine if the topological properties (Degree, Strength)
    observed in your real network are statistically significant or indistinguishable
    from random noise.

    Attributes
    ----------
    data : pd.DataFrame
        The original time-series data.
    threshold : float
        The correlation threshold used for network construction.
    weighted : bool
        If True, calculates weighted strength based on correlation coefficients.
    null_degrees : pd.DataFrame
        Stores the degree of every node for every null sample.
        Populated after calling `run()`.
    null_strengths : pd.DataFrame
        Stores the weighted strength of every node for every null sample.
        Populated after calling `run()`.
    sum_adjacency : np.ndarray
        The accumulated adjacency matrix of all null samples. 
        Cell [i, j] counts how many times an edge appeared between i and j.
    """

    def __init__(self, data: pd.DataFrame, threshold: float, weighted: bool = True):
        """Initialize the Null Hypothesis Sampler.

        Parameters
        ----------
        data : pd.DataFrame
            Time-series data where rows represent time steps and columns 
            represent nodes/variables.
        threshold : float
            The absolute correlation threshold. Edges are formed if 
            |correlation| >= threshold.
        weighted : bool, optional
            Whether to calculate metrics on the weighted graph (using correlation
            values as weights) or the binary graph, by default True.
        """
        self.data = data
        self.threshold = threshold
        self.weighted = weighted
        self.nodes = data.columns.tolist()
        self.n_nodes = len(self.nodes)
        # Cache stats for Gaussian Resampling method
        self.means = data.mean().values
        self.stds = data.std().values

        # Storage for results
        self.null_degrees: pd.DataFrame = pd.DataFrame()
        self.null_strengths: pd.DataFrame = pd.DataFrame()
        self.sum_adjacency: Optional[np.ndarray] = None
        self.n_samples_run: int = 0

    def run(self, 
            n_samples: int = 100, 
            method: str = 'shuffle', 
            seed: Optional[int] = None, 
            verbose: bool = True) -> None:
        """Execute the bootstrapping process.

        This method performs the following steps `n_samples` times:
        1. Shuffles each column of the data independently.
        2. Computes the correlation matrix.
        3. Applies the threshold to simulate a network.
        4. Calculates node degree and strength directly via matrix algebra.

        Parameters
        ----------
        n_samples : int, optional
            Number of null networks to generate, by default 100.
            Higher values (e.g., 1000) provide more precise significance bounds.
        method : str, optional
            - 'shuffle': Permutes time steps. Preserves outliers/distribution (Standard).
            - 'gaussian': Generates new data from Mean/Std. Destroys outliers (Stricter).
            - 'roll': Circular shift. Preserves local time-structure (autocorrelation).
        seed : int, optional
            Random seed for reproducibility, by default None.
        verbose : bool, optional
            If True, displays a progress bar, by default True.
        """
        # 1. Initialize Generator ONCE
        rng = np.random.default_rng(seed)
        
        self.n_samples_run = n_samples
        
        # Initialize the Sum Matrix (Reset if run is called again)
        self.sum_adjacency = np.zeros((self.n_nodes, self.n_nodes))

        # Pre-allocate output matrices
        deg_matrix = np.zeros((n_samples, self.n_nodes))
        str_matrix = np.zeros((n_samples, self.n_nodes))

        # Prepare data matrix
        matrix_values = self.data.values
        L, N = matrix_values.shape

        iterator = tqdm(range(n_samples), desc=f"Bootstrapping ({method})") if verbose else range(n_samples)
        
        for i in iterator:
            # --- 1. Generate Noise ---
            if method == 'shuffle':
                # Vectorized Shuffle
                raw_noise = matrix_values.copy()
                for col in range(N):
                    rng.shuffle(raw_noise[:, col])
                    
            elif method == 'gaussian':
                raw_noise = rng.normal(loc=self.means, scale=self.stds, size=(L, N))
            
            elif method == 'roll':
                raw_noise = np.empty_like(matrix_values)
                shifts = rng.integers(1, L, size=N)
                for col in range(N):
                    raw_noise[:, col] = np.roll(matrix_values[:, col], shifts[col])
            else:
                raise ValueError(f"Unknown method '{method}'")

            # --- 2. Compute Topology ---
            corr_mat = np.corrcoef(raw_noise, rowvar=False)
            np.nan_to_num(corr_mat, copy=False, nan=0.0)
            np.fill_diagonal(corr_mat, 0)
            
            # Binary Adjacency (Did the noise cross the threshold?)
            abs_corr = np.abs(corr_mat)
            adj_mask = (abs_corr >= self.threshold).astype(float)
            
            # --- 3. Accumulate Adjacency ---
            self.sum_adjacency += adj_mask  # <--- NEW LOGIC

            # --- 4. Store Metrics ---
            deg_matrix[i, :] = np.sum(adj_mask, axis=1)
            
            if self.weighted:
                weighted_adj = adj_mask * abs_corr
                str_matrix[i, :] = np.sum(weighted_adj, axis=1)

        # Save results
        sample_indices = [f"sample_{k+1}" for k in range(n_samples)]
        self.null_degrees = pd.DataFrame(deg_matrix, index=sample_indices, columns=self.nodes)
        self.null_strengths = pd.DataFrame(str_matrix, index=sample_indices, columns=self.nodes)
    
    def get_consensus_matrix(self, normalize: bool = False) -> pd.DataFrame:
        """Export the sum of adjacency matrices from the null models.

        Args:
            normalize (bool): 
                - If False (default), returns the raw count (0 to n_samples).
                - If True, returns probabilities (0.0 to 1.0).

        Returns:
            pd.DataFrame: A symmetric matrix where cell (i, j) indicates how often
                          an edge appeared between node i and j in the null models.
        """
        if self.sum_adjacency is None:
            raise ValueError("Run the sampler first.")
            
        matrix = self.sum_adjacency.copy()
        
        if normalize and self.n_samples_run > 0:
            matrix /= self.n_samples_run
            
        return pd.DataFrame(matrix, index=self.nodes, columns=self.nodes)

    def get_significance_thresholds(self, percentile: float = 95.0) -> pd.DataFrame:
        """Calculate the statistical significance thresholds.

        Determines the critical value above which a network property is considered
        statistically significant (i.e., unlikely to have occurred by chance).

        Parameters
        ----------
        percentile : float, optional
            The confidence level (e.g., 95.0 for p < 0.05), by default 95.0.

        Returns
        -------
        pd.DataFrame
            A DataFrame indexed by node, containing:
            - degree_critical_value: The 95th percentile of the null degree distribution.
            - strength_critical_value: The 95th percentile of the null strength distribution.
            - degree_mean_null: The average degree expected by random chance.
            - strength_mean_null: The average strength expected by random chance.

        Raises
        ------
        ValueError
            If `run()` has not been called yet.
        """
        if self.null_degrees.empty:
            raise ValueError("Model has not been run. Please call .run() first.")

        stats = pd.DataFrame(index=self.nodes)
        
        # Calculate Degree Stats
        stats['degree_critical_value'] = np.percentile(self.null_degrees, percentile, axis=0)
        stats['degree_mean_null'] = self.null_degrees.mean(axis=0)
        
        # Calculate Strength Stats
        stats['strength_critical_value'] = np.percentile(self.null_strengths, percentile, axis=0)
        stats['strength_mean_null'] = self.null_strengths.mean(axis=0)
        
        return stats