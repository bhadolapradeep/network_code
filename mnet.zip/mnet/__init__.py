# multinet/__init__.py

__version__ = "0.1.0"
print(f"Multinet version {__version__} loaded.")

# Expose the main workflow class and other high-level tools
from .workflow import SystemAnalyzer
from .comparison import Comparator

# You can also expose the subpackages themselves
from . import network
from . import analysis
from . import multiplex
from . import visualize