import pandas as pd
import numpy as np
from typing import Dict, Any, Optional

# Internal imports from previous steps
from ..network.filtering import compute_spectral_properties, compute_entropy_metrics
from ..network.null_models import analyze_spectral_null_model

try:
    from tqdm import tqdm
except ImportError:
    # Fallback if tqdm is not installed
    def tqdm(iterable, **kwargs): return iterable

def analyze_multiplex_rmt(
    layer_data_dict: Dict[str, pd.DataFrame], 
    n_samples: int = 100,
    seed: Optional[int] = None,
    verbose: bool = True
) -> Dict[str, Dict[str, Any]]:
    """
    Perform a comparative RMT analysis (Actual vs. Null) for every layer.

    For each layer in the multiplex system, this function:
    1. Computes the actual spectral properties (Eigenvalues, Eigenvectors, Entropy).
    2. Runs a Global Shuffle Null Model to generate a noise baseline.
    3. Packages the results for comparison.

    Parameters
    ----------
    layer_data_dict : Dict[str, pd.DataFrame]
        A dictionary where keys are layer names and values are the time-series
        DataFrames (Rows=Time, Cols=Nodes).
    n_samples : int, optional
        Number of null model reshuffles to perform per layer, by default 100.
    seed : int, optional
        Random seed for reproducibility. If provided, it is incremented
        for each layer to ensure distinct randomness.
    verbose : bool, optional
        If True, displays a progress bar.

    Returns
    -------
    Dict[str, Dict[str, Any]]
        A nested dictionary structured as:
        {
            'LayerName': {
                'actual': { ... results from compute_spectral_properties ... },
                'null':   { ... results from analyze_spectral_null_model ... }
            },
            ...
        }
    """
    comparison_results = {}
    
    # Sort keys for consistent processing order
    layer_names = sorted(layer_data_dict.keys())
    
    iterator = tqdm(layer_names, desc="Analyzing RMT per layer") if verbose else layer_names

    for i, layer_name in enumerate(iterator):
        df = layer_data_dict[layer_name]
        
        # Handle seed increment to ensure layers don't get identical random streams
        current_seed = seed + i if seed is not None else None

        # -----------------------------
        # A. Analyze Actual System
        # -----------------------------
        evals, evecs, off_diag = compute_spectral_properties(df)
        comp_df, ents = compute_entropy_metrics(evecs, node_labels=df.columns.tolist())
        
        # Format entropy as a DataFrame for consistency with previous user logic
        actual_total_ent = ents.to_frame(name='Actual').T

        actual_results = {
            "off_diagonal_values": off_diag,
            "eigenvalues": evals,
            "eigenvectors": pd.DataFrame(
                evecs, 
                index=df.columns, 
                columns=[f"eig_vec_{j+1}" for j in range(df.shape[1])]
            ),
            "square_eigenvectors": comp_df,
            "total_avg_entropy": actual_total_ent
        }

        # -----------------------------
        # B. Analyze Null Model
        # -----------------------------
        # Note: We use the function created in the previous turn
        null_results = analyze_spectral_null_model(
            df, 
            n_samples=n_samples, 
            seed=current_seed
        )

        # -----------------------------
        # C. Store Results
        # -----------------------------
        comparison_results[layer_name] = {
            "actual": actual_results,
            "null": null_results
        }
    
    return comparison_results