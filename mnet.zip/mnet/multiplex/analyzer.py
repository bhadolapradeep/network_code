# multinetlib/multiplex/analyzer.py

import pandas as pd
import numpy as np
from typing import Tuple

def get_multilink_locations(multi_adj_unweighted: pd.DataFrame) -> pd.DataFrame:
    """Compute a matrix identifying the multilink connecting each pair of nodes.

    This function transforms a multi-adjacency matrix into a single N x N
    matrix where each element `[i, j]` contains a unique integer ID
    representing the multilink connecting node `i` and node `j`.

    The integer ID is derived by converting the multilink's binary string
    representation to a base-10 integer (e.g., '011' -> 3). A value of 0
    indicates no connection on any multilink.

    Parameters
    ----------
    multi_adj_unweighted : pd.DataFrame
        The unweighted multi-adjacency matrix, with a pd.MultiIndex of
        ('multilink', 'node') and node names as columns.

    Returns
    -------
    pd.DataFrame
        An N x N DataFrame where each cell (i, j) contains the integer ID of
        the multilink connecting the two nodes, or 0 if they are not connected.
    """
    if not isinstance(multi_adj_unweighted.index, pd.MultiIndex) or \
       'multilink' not in multi_adj_unweighted.index.names:
        raise ValueError("Input DataFrame must have a MultiIndex with 'multilink'.")

    nodes_list = multi_adj_unweighted.columns.tolist()
    location_matrix = pd.DataFrame(0, index=nodes_list, columns=nodes_list)

    for multilink_name, group_df in multi_adj_unweighted.groupby(level='multilink'):
        multilink_id = int(multilink_name, 2)

        # Create the boolean mask
        mask = group_df > 0
        
        # Drop the 'multilink' level from the mask's index so it can be
        # aligned with the simple index of location_matrix.
        mask.index = mask.index.droplevel('multilink')
        
        # Now the assignment will work because the indexes are compatible
        location_matrix[mask] = multilink_id
        
    return location_matrix

def rank_nodes_by_property(property_series: pd.Series) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Rank nodes within each multilink based on a given property.

    This function takes a Series of node properties (like multidegree or
    multistrength), which has a MultiIndex of ('multilink', 'node'), and
    sorts the nodes within each multilink group to create a ranked list.

    Parameters
    ----------
    property_series : pd.Series
        A pandas Series with a MultiIndex ('multilink', 'node') and property
        values.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        A tuple containing two DataFrames:
        - ranked_nodes_df: Rows are multilinks, columns are ranks (Rank_1,
          Rank_2,...), and values are the node labels.
        - ranked_values_df: Has the same structure but contains the
          corresponding property values.
    """
    ranked_nodes_list = []
    ranked_values_list = []
    multilink_index = []

    for name, group in property_series.groupby(level='multilink'):
        sorted_group = group.sort_values(ascending=False)
        multilink_index.append(name)
        ranked_nodes_list.append(list(sorted_group.index.get_level_values('node')))
        ranked_values_list.append(list(sorted_group.values))

    if not ranked_nodes_list:
        return pd.DataFrame(), pd.DataFrame()

    num_nodes = len(ranked_nodes_list[0])
    rank_columns = [f'Rank_{i+1}' for i in range(num_nodes)]

    ranked_nodes_df = pd.DataFrame(ranked_nodes_list, index=multilink_index, columns=rank_columns)
    ranked_values_df = pd.DataFrame(ranked_values_list, index=multilink_index, columns=rank_columns)
    
    return ranked_nodes_df, ranked_values_df