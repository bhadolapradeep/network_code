# multinetlib/multiplex/multilink_matrix.py

import pandas as pd
import numpy as np
import networkx as nx
from itertools import product
from typing import Tuple, Dict, Optional, List

def _compute_multiplex_logic(adj_weighted: Dict[str, pd.DataFrame]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Core logic for computing multi-adjacency matrices from pre-aligned
    weighted adjacency matrices. (Internal Function)
    """
    layers = sorted(adj_weighted.keys())
    nodes_list = adj_weighted[layers[0]].index.tolist()
    num_layers = len(layers)
    num_nodes = len(nodes_list)

    mlink_list = [''.join(p) for p in product('01', repeat=num_layers)]
    if '0' * num_layers in mlink_list:
        mlink_list.remove('0' * num_layers)

    adj_binary = {layer: (df > 0).astype(int) for layer, df in adj_weighted.items()}
    adj_binary_inv = {layer: (1 - mat) for layer, mat in adj_binary.items()}

    multi_adj_unweighted_mats = []
    multi_adj_weighted_mats = []

    for mlink in mlink_list:
        m_adj_unweighted = np.ones((num_nodes, num_nodes))
        for i, m_alpha in enumerate(mlink):
            layer_name = layers[i]
            if m_alpha == '1':
                m_adj_unweighted *= adj_binary[layer_name].values
            else:
                m_adj_unweighted *= adj_binary_inv[layer_name].values
        
        m_adj_weighted_sum = np.zeros((num_nodes, num_nodes))
        for i, m_alpha in enumerate(mlink):
            if m_alpha == '1':
                layer_name = layers[i]
                m_adj_weighted_sum += adj_weighted[layer_name].values
        
        final_weighted = m_adj_unweighted * m_adj_weighted_sum
        
        multi_adj_unweighted_mats.append(m_adj_unweighted)
        multi_adj_weighted_mats.append(final_weighted)

    multiindex = pd.MultiIndex.from_product([mlink_list, nodes_list], names=['multilink', 'node'])
    df_unweighted = pd.DataFrame(np.vstack(multi_adj_unweighted_mats), index=multiindex, columns=nodes_list)
    df_weighted = pd.DataFrame(np.vstack(multi_adj_weighted_mats), index=multiindex, columns=nodes_list)

    return df_unweighted, df_weighted


def compute_multiplex_from_adjacencies(adj_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Compute multi-adjacency matrices from a single stacked DataFrame.

    This function takes a tidy DataFrame containing multiple, stacked adjacency
    matrices, which are distinguished by a 'layer' column. It parses this
    DataFrame and then applies the formal mathematical definition for
    constructing multiplex networks.

    Parameters
    ----------
    adj_df : pd.DataFrame
        A DataFrame where a 'layer' column specifies the layer, a 'node'
        column specifies the node for that row, and the remaining columns
        are the node names that form the adjacency matrix.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        A tuple containing:
        - multi_adj_unweighted: DataFrame of unweighted multi-adjacency matrices.
        - multi_adj_weighted: DataFrame of weighted multi-adjacency matrices.

    Raises
    ------
    ValueError
        If the input DataFrame is missing the required 'layer' or 'node' columns.
    """
    if 'layer' not in adj_df.columns or 'node' not in adj_df.columns:
        raise ValueError("Input DataFrame is missing the required 'layer' and/or 'node' columns.")

    # --- Convert the single tidy DataFrame into a dictionary of aligned matrices ---
    adjacencies = {}
    for layer_name, group_df in adj_df.groupby('layer'):
        # Define the matrix columns as all columns that aren't 'layer' or 'node'
        node_cols = [c for c in group_df.columns if c not in ['layer', 'node']]
        # Create the square matrix by setting the 'node' column as the index
        matrix = group_df.set_index('node')[node_cols]
        adjacencies[str(layer_name)] = matrix

    return _compute_multiplex_logic(adjacencies)


def compute_multiplex_from_graphs(graphs: Dict[str, nx.Graph], node_order: Optional[List[str]] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Compute multi-adjacency matrices from a dictionary of NetworkX graphs.

    This function provides a user-friendly interface that handles the conversion
    from NetworkX graph objects to the required adjacency matrix format, ensuring
    all matrices are properly aligned before computation.

    Parameters
    ----------
    graphs : Dict[str, nx.Graph]
        A dictionary where keys are layer names and values are the
        corresponding NetworkX Graph objects.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        A tuple containing:
        - multi_adj_unweighted: DataFrame of unweighted multi-adjacency matrices.
        - multi_adj_weighted: DataFrame of weighted multi-adjacency matrices.
    """
    if not graphs:
        raise ValueError("Input dictionary cannot be empty.")
        
    all_nodes = set()
    for g in graphs.values():
        all_nodes.update(g.nodes())

    # 1. Determine the Master Node Order
    if node_order is None:
        # Fallback: Create sorted union of all nodes across all layers
        all_nodes = set()
        for G in graphs.values():
            all_nodes.update(G.nodes())
        master_nodes = sorted(list(all_nodes))
    else:
        master_nodes = node_order
    
    master_nodes = sorted(list(all_nodes))

    adj_matrices = {}
    for layer_name, g in graphs.items():
        adj_df = nx.to_pandas_adjacency(g, nodelist=master_nodes, weight='weight')
        adj_matrices[layer_name] = adj_df
    
    return _compute_multiplex_logic(adj_matrices)

def compute_multiplex_from_df(adj_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Computes weighted and unweighted multi-adjacency matrices from a DataFrame.

    This function takes a tidy DataFrame containing stacked, weighted adjacency
    matrices for multiple layers, identified by a 'layer' column. It then
    calculates the multi-adjacency matrix for every possible combination of
    layer states (multilinks).

    Parameters
    ----------
    adj_df : pd.DataFrame
        A DataFrame where an index and a 'node' column represent node names, 
        other columns represent node names, and an additional 'layer' column 
        specifies the layer for each matrix.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        A tuple containing:
        - multi_adj_unweighted: DataFrame of unweighted multi-adjacency matrices.
        - multi_adj_weighted: DataFrame of weighted multi-adjacency matrices.
    """
    if 'layer' not in adj_df.columns:
        raise ValueError("Input DataFrame is missing the required 'layer' column.")

    layers = sorted(list(adj_df['layer'].unique()))
    num_layers = len(layers)
    nodes_list = adj_df['node'].unique().tolist()
    num_nodes = len(nodes_list)

    binary_tuples = product([0, 1], repeat=num_layers)
    mlink_list = [''.join(map(str, bits)) for bits in binary_tuples]
    mlink_list.remove('0' * num_layers)

    adj_wt_dict = {}
    for layer in layers:
        matrix = adj_df[adj_df['layer'] == layer].drop(columns=['layer', 'node']).set_index(pd.Index(nodes_list))
        adj_wt_dict[layer] = matrix.reindex(index=nodes_list, columns=nodes_list).to_numpy()

    adj_bin_dict = {layer: (adj > 0).astype(int) for layer, adj in adj_wt_dict.items()}
    inv_adj_bin_dict = {layer: 1 - adj for layer, adj in adj_bin_dict.items()}

    multi_adj_unweighted_mats = []
    multi_adj_weighted_mats = []

    for mlink in mlink_list:
        m_adj_unweighted = np.ones((num_nodes, num_nodes))
        m_adj_weighted = np.zeros((num_nodes, num_nodes))
        for i, bit_char in enumerate(mlink):
            layer_name = layers[i]
            if bit_char == '1':
                m_adj_unweighted *= adj_bin_dict[layer_name]
                m_adj_weighted += adj_wt_dict[layer_name]
            else:
                m_adj_unweighted *= inv_adj_bin_dict[layer_name]
                m_adj_weighted += inv_adj_bin_dict[layer_name]
        final_weighted = m_adj_unweighted * m_adj_weighted    
        multi_adj_unweighted_mats.append(m_adj_unweighted)
        multi_adj_weighted_mats.append(final_weighted)

    multiindex = pd.MultiIndex.from_product([mlink_list, nodes_list], names=['multilink', 'node'])
    final_unweighted = np.vstack(multi_adj_unweighted_mats)
    final_weighted = np.vstack(multi_adj_weighted_mats)

    multi_adj_unweighted = pd.DataFrame(final_unweighted, index=multiindex, columns=nodes_list)
    multi_adj_weighted = pd.DataFrame(final_weighted, index=multiindex, columns=nodes_list)

    return multi_adj_unweighted, multi_adj_weighted

def compute_multiplex_from_graphs_dict(graphs: Dict[str, nx.Graph]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Compute weighted and unweighted multi-adjacency matrices from graphs.

    This function calculates the multi-adjacency matrix for every possible
    combination of layer states (multilinks) from a dictionary of
    NetworkX graphs.

    Parameters
    ----------
    graphs : Dict[str, nx.Graph]
        A dictionary where keys are layer names and values are the
        corresponding NetworkX graphs.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        A tuple containing:
        - multi_adj_unweighted: DataFrame of unweighted multi-adjacency matrices.
        - multi_adj_weighted: DataFrame of weighted multi-adjacency matrices.
    """
    layers = sorted(graphs.keys())
    num_layers = len(layers)
    
    all_nodes = set()
    for g in graphs.values():
        all_nodes.update(g.nodes())
    nodes_list = sorted(list(all_nodes))
    num_nodes = len(nodes_list)

    mlink_list = [''.join(p) for p in product('01', repeat=num_layers)]
    if '0' * num_layers in mlink_list:
        mlink_list.remove('0' * num_layers)

    adj_wt_dict = {layer: nx.to_numpy_array(g, nodelist=nodes_list, weight='weight') for layer, g in graphs.items()}
    adj_bin_dict = {layer: (adj > 0).astype(int) for layer, adj in adj_wt_dict.items()}
    inv_adj_bin_dict = {layer: 1 - adj for layer, adj in adj_bin_dict.items()}

    multi_adj_unweighted_mats = []
    multi_adj_weighted_mats = []

    for mlink in mlink_list:
        m_adj_unweighted = np.ones((num_nodes, num_nodes))
        m_adj_weighted = np.zeros((num_nodes, num_nodes))
        for i, bit_char in enumerate(mlink):
            layer_name = layers[i]
            if bit_char == '1':
                m_adj_unweighted *= adj_bin_dict[layer_name]
                m_adj_weighted += adj_wt_dict[layer_name]
            else: # bit_char == '0'
                m_adj_unweighted *= inv_adj_bin_dict[layer_name]
                m_adj_weighted += inv_adj_bin_dict[layer_name]
        # Weighted matrix calculation needs care
        # A node pair contributes to the sum only if the edge exists on all '1' layers and not on any '0' layers
        # The unweighted matrix correctly identifies these locations.
        final_weighted = m_adj_unweighted * m_adj_weighted

        multi_adj_unweighted_mats.append(m_adj_unweighted)
        multi_adj_weighted_mats.append(final_weighted)

    multiindex = pd.MultiIndex.from_product([mlink_list, nodes_list], names=['multilink', 'node'])
    
    df_unweighted = pd.DataFrame(np.vstack(multi_adj_unweighted_mats), index=multiindex, columns=nodes_list)
    df_weighted = pd.DataFrame(np.vstack(multi_adj_weighted_mats), index=multiindex, columns=nodes_list)

    return df_unweighted, df_weighted
