# multinetlib/multiplex/edge_analysis.py

import pandas as pd
import numpy as np

def calculate_average_overlapping_degree(multi_adj_unweighted: pd.DataFrame) -> pd.DataFrame:
    """Calculate the average overlapping degree of the multiplex network.

    This metric provides a single value representing the overall edge overlap
    across all layers, normalized by the total number of possible overlaps.

    Parameters
    ----------
    multi_adj_unweighted : pd.DataFrame
        The binary (unweighted) multiplex adjacency DataFrame.

    Returns
    -------
    pd.DataFrame
        A single-row DataFrame with the calculated average overlapping degree.
    """
    if multi_adj_unweighted.empty:
        return pd.DataFrame([{'average_overlapping_degree': 0.0}])

    multilinks = multi_adj_unweighted.index.get_level_values('multilink').unique()
    num_layers = len(multilinks[0])
    num_nodes = len(multi_adj_unweighted.columns)

    sum_of_degrees_per_multilink = multi_adj_unweighted.sum(axis=1).groupby(level='multilink').sum()

    overlap_sum = 0
    for multilink, total_degree_sum in sum_of_degrees_per_multilink.items():
        # The overlap number for a multilink is its number of active layers
        overlap_num = sum(c == '1' for c in multilink)
        # Contribution is (o-1) * sum_of_degrees
        overlap_sum += (overlap_num - 1) * total_degree_sum
    
    denominator = (num_layers - 1) * num_nodes * (num_nodes - 1)
    avg_overlap = overlap_sum / denominator if denominator > 0 else 0.0
    
    return pd.DataFrame([{'average_overlapping_degree': avg_overlap}])


def calculate_multilink_uniqueness(multi_adj_unweighted: pd.DataFrame) -> pd.DataFrame:
    """Calculate the uniqueness of each multilink configuration.

    Uniqueness is the fraction of all unique edges in the aggregate network
    that exist *only* in that specific multilink configuration.

    Parameters
    ----------
    multi_adj_unweighted : pd.DataFrame
        The binary (unweighted) multiplex adjacency DataFrame.

    Returns
    -------
    pd.DataFrame
        A DataFrame with the uniqueness ratio for each multilink.
    """
    if multi_adj_unweighted.empty:
        return pd.DataFrame(columns=['uniqueness_ratio'])
        
    edges_per_multilink = multi_adj_unweighted.sum(axis=1).groupby(level='multilink').sum() / 2
    total_unique_edges = edges_per_multilink.sum()
    
    if total_unique_edges == 0:
        return pd.DataFrame({'uniqueness_ratio': 0.0}, index=edges_per_multilink.index)
        
    uniqueness_ratio = edges_per_multilink / total_unique_edges
    return uniqueness_ratio.to_frame(name='uniqueness_ratio')