# multinetlib/multiplex/properties.py

import pandas as pd
import networkx as nx
import numpy as np
from typing import Dict

def calculate_node_versatility(graphs: Dict[str, nx.Graph]) -> pd.Series:
    """Calculate the versatility of each node in a multiplex network.

    Versatility measures how a node's connection strength is distributed
    across the different layers. A versatility of 0 indicates that a node's
    entire strength is concentrated in a single layer. A high versatility
    (approaching 1) means the strength is evenly distributed.

    Parameters
    ----------
    graphs : Dict[str, nx.Graph]
        A dictionary where keys are layer names and values are the
        corresponding NetworkX graphs.

    Returns
    -------
    pd.Series
        A pandas Series where the index contains node labels and values are
        the versatility scores.

    Notes
    -----
    Versatility `V_i` for a node `i` is calculated as:
    `V_i = 1 - sum([(s_il / S_i)^2 for l in layers])`
    where `s_il` is the strength of node `i` in layer `l` and `S_i` is the
    total strength of node `i` across all layers.

    Examples
    --------
    >>> import networkx as nx
    >>> import pandas as pd
    >>> g1 = nx.Graph()
    >>> g1.add_edge('A', 'B', weight=2)
    >>> g2 = nx.Graph()
    >>> g2.add_edge('A', 'C', weight=2)
    >>> graphs = {'L1': g1, 'L2': g2}
    >>> versatility = calculate_node_versatility(graphs)
    >>> print(versatility['A'])
    0.5
    """
    all_nodes = set()
    for g in graphs.values():
        all_nodes.update(g.nodes())

    total_strength = pd.Series(0.0, index=list(all_nodes))
    strengths_by_layer = {}

    for layer, G in graphs.items():
        strength = pd.Series(dict(G.degree(weight='weight')), dtype=float).reindex(all_nodes, fill_value=0)
        strengths_by_layer[layer] = strength
        total_strength = total_strength.add(strength, fill_value=0)

    participation_sum = pd.Series(0.0, index=total_strength.index)
    for layer_strength in strengths_by_layer.values():
        # Avoid division by zero for isolated nodes
        with np.errstate(divide='ignore', invalid='ignore'):
            proportion = layer_strength / total_strength
            proportion.fillna(0, inplace=True)
        participation_sum += proportion**2

    versatility = 1 - participation_sum
    return versatility


def compute_multidegree(multi_adj_unweighted: pd.DataFrame) -> pd.DataFrame:
    """Calculate the degree of each node for each multilink.

    The multidegree of a node for a given multilink is the number of
    connections it has within that specific multilink configuration.

    Parameters
    ----------
    multi_adj_unweighted : pd.DataFrame
        The unweighted multiplex adjacency DataFrame, with a MultiIndex
        of ('multilink', 'node') and node names as columns.

    Returns
    -------
    pd.DataFrame
        A DataFrame where rows are multilinks and columns are nodes, containing
        the degree of each node in each multilink.
    """
    # The degree of each node is the sum of its row in the adjacency matrix.
    degree_series = multi_adj_unweighted.sum(axis=1)
    multidegree_df = degree_series.unstack(level='node')
    return multidegree_df


def compute_multistrength(multi_adj_weighted: pd.DataFrame) -> pd.DataFrame:
    """Calculate the strength of each node for each multilink.

    The multistrength of a node for a given multilink is the sum of the
    weights of its connections within that specific multilink configuration.

    Parameters
    ----------
    multi_adj_weighted : pd.DataFrame
        The weighted multiplex adjacency DataFrame, with a MultiIndex
        of ('multilink', 'node').

    Returns
    -------
    pd.DataFrame
        A DataFrame where rows are multilinks and columns are nodes, containing
        the strength of each node in each multilink.
    """
    # The strength of each node is the sum of its row in the weighted adjacency matrix.
    strength_series = multi_adj_weighted.sum(axis=1)
    multistrength_df = strength_series.unstack(level='node')
    return multistrength_df