# multinetlib/visualize/plotting.py

import networkx as nx
import numpy as np
from typing import Dict, Optional, List, Tuple, Any

import networkx as nx
from typing import Dict
try:
    import matplotlib.pyplot as plt
    from pymnet import MultilayerNetwork, draw
except ImportError:
    plt = None; MultilayerNetwork = None; draw = None

try:
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
except ImportError:
    plt = None
    Patch = None

def plot_multilayer_network(
    graphs: Dict[str, nx.Graph],
    layout: str = 'spectral',
    **kwargs
) -> None:
    """Plot a multiplex network in a 3D visualization.

    This function converts a dictionary of NetworkX graphs into a `pymnet`
    MultilayerNetwork object and renders it as a 3D plot. It provides a
    powerful way to visualize the distinct layers and the connections
    within them.

    Parameters
    ----------
    graphs : Dict[str, nx.Graph]
        A dictionary where keys are string identifiers for the layers and
        values are the corresponding NetworkX Graph objects.
    layout : str, optional
        The layout algorithm to use for positioning nodes. The available
        options are determined by the `pymnet` library (e.g., 'spectral',
        'fr', 'random'). Defaults to 'spectral'.
    **kwargs
        Additional keyword arguments to be passed directly to the `pymnet.draw`
        function. This allows for extensive customization of the plot, such as
        `node_size`, `layer_gap`, `edge_width`, etc.

    Returns
    -------
    None
        This function displays a Matplotlib plot and does not return anything.

    Raises
    ------
    ImportError
        If the 'pymnet' or 'matplotlib' libraries are not installed.

    Examples
    --------
    >>> import networkx as nx
    >>> # Create two simple graphs for our layers
    >>> g1 = nx.path_graph(3)
    >>> g2 = nx.path_graph(3)
    >>> g2.add_edge(0, 2)
    >>> # Combine them into a dictionary
    >>> multiplex_graphs = {'Layer 1': g1, 'Layer 2': g2}
    >>> # Visualize the multilayer network
    >>> # Note: This will display a plot, so it's commented out for automated tests.
    >>> # plot_multilayer_network(multiplex_graphs, node_size=50, layer_gap=0.3)
    """
    if MultilayerNetwork is None:
        raise ImportError(
            "The 'pymnet' and 'matplotlib' libraries are required for plotting. "
            "Please install them."
        )

    # --- 1. Convert from NetworkX to Pymnet object ---
    mnet = MultilayerNetwork(aspects=1)
    for layer_name, graph in graphs.items():
        for u, v, data in graph.edges(data=True):
            # In pymnet, the edge connects (node, layer) to (node, layer)
            mnet[u, v, layer_name, layer_name] = data.get('weight', 1.0)

    # --- 2. Create and display the plot with 3D projection ---
    fig = plt.figure(figsize=(12, 9))

    # Create an axes object with a 3D projection
    ax = fig.add_subplot(111, projection='3d')

    draw(mnet,
         layout=layout,
         ax=ax,
         **kwargs)

    plt.show()

def plot_multilayer_network_custom(
    graphs: Dict[str, nx.Graph],
    layout: str = 'circular',
    node_labels: Dict = None,
    node_colors: Dict = None,
    node_size: int = 30,
    node_label_fontsize: int = 8,
    edge_alpha: float = 0.2,
    edge_linewidth: float = 0.5,
    layer_gap: float = 1.5,
    **kwargs
) -> None:
    """Plot a customized 3D visualization of a multiplex network.

    This function provides a high-level interface for creating detailed 3D
    plots of multilayer networks using `pymnet`. It handles the conversion
    from NetworkX and ensures all nodes are represented across all layers for
    a consistent layout, while exposing common styling options.

    Parameters
    ----------
    graphs : Dict[str, nx.Graph]
        A dictionary where keys are layer names and values are the
        corresponding NetworkX Graph objects.
    layout : str, optional
        The layout algorithm to use for positioning nodes, passed to `pymnet`.
        Defaults to 'circular'.
    node_labels : Dict, optional
        A dictionary mapping node identifiers to their desired display labels.
        If None, the original node identifiers are used. Defaults to None.
    node_colors : Dict, optional
        A dictionary mapping node identifiers to color strings (e.g., 'red',
        '#FF0000'). Defaults to None.
    node_size : int, optional
        The size of all nodes in the plot. Defaults to 30.
    node_label_fontsize : int, optional
        The font size for node labels. Defaults to 8.
    edge_alpha : float, optional
        The transparency (alpha) of the edges. Defaults to 0.2.
    edge_linewidth : float, optional
        The width of the edges. Defaults to 0.5.
    layer_gap : float, optional
        The spacing between layers in the 3D visualization. Defaults to 1.5.
    **kwargs
        Additional keyword arguments passed directly to the `pymnet.draw`
        function for advanced customization.

    Returns
    -------
    None
        This function displays a Matplotlib plot and does not return anything.

    Raises
    ------
    ImportError
        If the 'pymnet' or 'matplotlib' libraries are not installed.

    See Also
    --------
    plot_multilayer_network : A simpler version for basic 3D plotting.

    Examples
    --------
    >>> import networkx as nx
    >>> g1 = nx.Graph([('A', 'B'), ('B', 'C')])
    >>> g2 = nx.Graph([('A', 'C')])
    >>> multiplex_graphs = {'L1': g1, 'L2': g2}
    >>> labels = {'A': 'Node A', 'B': 'Node B', 'C': 'Node C'}
    >>> colors = {'A': 'red', 'B': 'blue', 'C': 'green'}
    >>> # The following line would display a customized 3D plot.
    >>> # plot_multilayer_network_custom(
    ... #     multiplex_graphs,
    ... #     node_labels=labels,
    ... #     node_colors=colors,
    ... #     node_size=100,
    ... #     layer_gap=2.0
    ... # )
    """
    if MultilayerNetwork is None:
        raise ImportError("`pymnet` and `matplotlib` are required for plotting.")

    mnet = MultilayerNetwork(aspects=1)
    all_nodes = set()
    for g in graphs.values():
        all_nodes.update(g.nodes())
    # Explicitly add all unique nodes to each layer to ensure consistent layout
    for node in all_nodes:
        for layer in graphs.keys():
            mnet.add_node(node, layer)

    for layer_name, graph in graphs.items():
        for u, v, data in graph.edges(data=True):
            mnet[u, v, layer_name, layer_name] = data.get('weight', 1.0)

    fig = plt.figure(figsize=(15, 12))
    ax = fig.add_subplot(111, projection='3d')

    # Create style dictionaries required by pymnet from the simpler inputs
    node_label_size_dict = {node: node_label_fontsize for node in all_nodes}
    node_size_dict = {node: node_size for node in all_nodes}

    draw(
        mnet,
        layout=layout,
        ax=ax,
        nodeLabelDict=node_labels,
        nodeColorDict=node_colors,
        nodeSizeDict=node_size_dict,
        nodeLabelSizeDict=node_label_size_dict,
        defaultEdgeColor='gray',
        defaultEdgeAlpha=edge_alpha,
        defaultEdgeWidth=edge_linewidth,
        layergap=layer_gap,
        **kwargs
    )
    plt.show()

def plot_community_network(graph: nx.Graph, community_map: Dict[str, int], **kwargs):
    """Plot a network with nodes colored by community assignment.

    This function provides a visualization of community structures within a
    network. It uses a colormap to assign a distinct color to each
    community, making the clusters visually apparent.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph to be plotted.
    community_map : Dict[str, int]
        A dictionary mapping each node identifier to an integer that represents
        its community ID. This is typically the output of a community
        detection algorithm.
    **kwargs
        Additional keyword arguments to be passed directly to the
        `networkx.draw` function for further customization (e.g., `node_size`,
        `font_color`, `width`).

    Returns
    -------
    None
        This function displays a Matplotlib plot and does not return anything.

    See Also
    --------
    multinetlib.analysis.community.detect_communities : Function to generate a community map.

    Examples
    --------
    >>> import networkx as nx
    >>> G = nx.karate_club_graph()
    >>> # A simple, predefined community map for demonstration
    >>> community_map = {node: data['club'] for node, data in G.nodes(data=True)}
    >>> # The following line would display a colored plot of the network.
    >>> # plot_community_network(G, community_map, with_labels=False, node_size=50)
    """
    node_colors = [community_map.get(node, -1) for node in graph.nodes()]
    plt.figure(figsize=(10, 8))
    pos = nx.spring_layout(graph, seed=42)
    nx.draw(graph, pos, node_color=node_colors, cmap=plt.cm.viridis, with_labels=True, **kwargs)
    plt.title("Network Community Structure")
    plt.show()

def plot_network_diff(graph1: nx.Graph, graph2: nx.Graph, labels: Tuple[str, str] = ('Network 1', 'Network 2')):
    """Visualize the structural differences between two networks.

    This function generates a side-by-side comparison of two graphs,
    highlighting the edges that are common, those that have been removed
    (exist in graph1 but not graph2), and those that have been added
    (exist in graph2 but not graph1). Node positions are kept consistent
    across both plots for a clear comparison.

    Parameters
    ----------
    graph1 : nx.Graph
        The first network, often considered the baseline or "before" state.
    graph2 : nx.Graph
        The second network, often the "after" state to be compared against
        the first.
    labels : Tuple[str, str], optional
        A tuple of two strings to use as titles for the left and right
        subplots, respectively. Defaults to ('Network 1', 'Network 2').

    Returns
    -------
    None
        This function displays a Matplotlib plot and does not return anything.

    Examples
    --------
    >>> import networkx as nx
    >>> # Create two graphs with some common and some different edges
    >>> g1 = nx.Graph([('A', 'B'), ('B', 'C')])
    >>> g2 = nx.Graph([('B', 'C'), ('C', 'D')])
    >>> # The following line would display a side-by-side plot highlighting
    >>> # the removed edge ('A', 'B') and the added edge ('C', 'D').
    >>> # plot_network_diff(g1, g2, labels=('Before', 'After'))
    """
    # Use the union of nodes for a consistent layout
    all_nodes = list(set(graph1.nodes()) | set(graph2.nodes()))
    pos = nx.spring_layout(all_nodes, seed=42)

    # Determine edge differences
    edges1, edges2 = set(graph1.edges()), set(graph2.edges())
    common = list(edges1 & edges2)
    removed = list(edges1 - edges2)
    added = list(edges2 - edges1)

    fig, axes = plt.subplots(1, 2, figsize=(16, 8))

    # --- Plot for Graph 1 (showing removed edges) ---
    axes[0].set_title(f"{labels[0]} (Red = Removed)")
    nx.draw_networkx_nodes(graph1, pos, ax=axes[0], node_color='skyblue')
    nx.draw_networkx_labels(graph1, pos, ax=axes[0])
    nx.draw_networkx_edges(graph1, pos, ax=axes[0], edgelist=common, edge_color='silver', width=1.5)
    nx.draw_networkx_edges(graph1, pos, ax=axes[0], edgelist=removed, edge_color='red', style='dashed', width=2.0)

    # --- Plot for Graph 2 (showing added edges) ---
    axes[1].set_title(f"{labels[1]} (Green = Added)")
    nx.draw_networkx_nodes(graph2, pos, ax=axes[1], node_color='skyblue')
    nx.draw_networkx_labels(graph2, pos, ax=axes[1])
    nx.draw_networkx_edges(graph2, pos, ax=axes[1], edgelist=common, edge_color='silver', width=1.5)
    nx.draw_networkx_edges(graph2, pos, ax=axes[1], edgelist=added, edge_color='green', style='solid', width=2.0)

    plt.suptitle("Network Difference Visualization", fontsize=16)
    plt.show()

def plot_single_layer_custom(
    graph: nx.Graph,
    layout: str = 'spring',
    title: str = 'Custom Network Plot',
    node_labels: Optional[Dict] = None,
    node_colors: Optional[Dict] = None,
    sorted_nodelist: Optional[List] = None,
    output_filename: Optional[str] = None,
    node_size: int = 50,
    node_label_fontsize: int = 8,
    edge_alpha: float = 0.3,
    edge_linewidth: float = 0.5,
    legend_handles: Optional[List] = None
):
    """Generate a highly customized plot of a single-layer network.

    This function provides extensive control over the visual appearance of a
    network graph, including layout, colors, labels, and sizes. It can either
    display the plot directly or save it to high-quality image files (PNG and EPS),
    making it suitable for both interactive exploration and automated script execution.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph object to be plotted.
    layout : str, optional
        The node layout algorithm to use ('spring', 'circular', etc.).
        Defaults to 'spring'.
    title : str, optional
        The title for the plot. Defaults to 'Custom Network Plot'.
    node_labels : Dict, optional
        A dictionary mapping node identifiers to their desired display labels.
        If None, node identifiers themselves are used. Defaults to None.
    node_colors : Dict, optional
        A dictionary mapping node identifiers to color strings. Defaults to None.
    sorted_nodelist : List, optional
        A list of node identifiers in a specific order, which is used to
        structure the 'circular' layout. Defaults to None.
    output_filename : str, optional
        The base path and name for the output file (without extension). If provided,
        the plot is saved as both a .png and .eps file and the figure is closed
        to conserve memory. If None, the plot is displayed interactively.
        Defaults to None.
    node_size : int, optional
        The size of the nodes. Defaults to 50.
    node_label_fontsize : int, optional
        The font size for the node labels. Defaults to 8.
    edge_alpha : float, optional
        The transparency of the edges, from 0.0 (transparent) to 1.0 (opaque).
        Defaults to 0.3.
    edge_linewidth : float, optional
        The width of the edges. Defaults to 0.5.
    legend_handles : List, optional
        A list of Matplotlib Patch objects to be used for creating a custom
        legend (e.g., for node colors by region). Defaults to None.

    Returns
    -------
    None
        This function either displays or saves a plot and does not return any value.

    Examples
    --------
    >>> import networkx as nx
    >>> import matplotlib.pyplot as plt
    >>> from matplotlib.patches import Patch
    >>> G = nx.karate_club_graph()
    >>> colors = {i: 'blue' if G.nodes[i]['club'] == 'Mr. Hi' else 'red' for i in G.nodes}
    >>> legend = [Patch(color='blue', label='Mr. Hi'), Patch(color='red', label='Officer')]
    >>> # To save the plot to files named 'karate_club.png' and 'karate_club.eps'
    >>> # plot_single_layer_custom(
    ... #     G,
    ... #     title="Karate Club Network",
    ... #     node_colors=colors,
    ... #     legend_handles=legend,
    ... #     output_filename="karate_club"
    ... # )
    """
    fig, ax = plt.subplots(figsize=(20, 20))

    # Prepare node attributes for drawing
    nodes_in_graph = list(graph.nodes())
    color_list = [node_colors.get(str(node), 'gray') for node in nodes_in_graph] if node_colors else 'gray'
    labels_to_draw = {node: node_labels.get(str(node), str(node)) for node in nodes_in_graph} if node_labels else {}


    # Calculate node positions based on the chosen layout
    pos = {}
    if layout == 'circular' and sorted_nodelist:
        # Filter the sorted list to only include nodes present in the current graph
        ordered_nodes = [node for node in sorted_nodelist if node in nodes_in_graph]
        if ordered_nodes:
            angle_map = {node: i * 2 * np.pi / len(ordered_nodes) for i, node in enumerate(ordered_nodes)}
            pos = {node: (np.cos(angle), np.sin(angle)) for node, angle in angle_map.items()}
        else: # Fallback if no sorted nodes are in the graph
            pos = nx.spring_layout(graph, seed=42)
    else:
        pos = nx.spring_layout(graph, seed=42)

    # Drawing the Network
    nx.draw_networkx(
        graph, pos=pos, labels=labels_to_draw, nodelist=nodes_in_graph,
        node_color=color_list, node_size=node_size, font_size=node_label_fontsize,
        width=edge_linewidth, edge_color=[0.5, 0.5, 0.5, edge_alpha]
    )

    if legend_handles:
        ax.legend(handles=legend_handles, title="Regions", loc="upper right")

    plt.title(title, fontsize=24)
    plt.box(False) # Remove the plot box/frame

    # Conditional output: save to file or show interactively
    if output_filename:
        # Save the figure in both PNG and high-resolution EPS formats
        plt.savefig(f"{output_filename}.png", bbox_inches='tight', dpi=300)
        plt.savefig(f"{output_filename}.eps", format='eps', bbox_inches='tight')
        plt.close(fig) # IMPORTANT: Close the figure to free up memory in a loop
    else:
        plt.show()