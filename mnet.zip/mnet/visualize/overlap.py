import pandas as pd
import matplotlib.pyplot as plt
from typing import Dict, Optional, List, Tuple
import networkx as nx

# Internal library import
from ..multiplex.multilink_matrix import compute_multiplex_from_graphs

try:
    from upsetplot import plot as up_plot
except ImportError:
    up_plot = None

def plot_multiplex_upset(
    graphs: Dict[str, nx.Graph], 
    title: str = "Multiplex Edge Overlap", 
    save_path: Optional[str] = None
) -> None:
    """
    Generate an Upset plot showing edge overlaps across multiplex layers.
    
    This function optimizes the extraction of overlapping edges by using
    vectorized operations from the multiplex matrix logic, avoiding O(N^2) loops.

    Parameters
    ----------
    graphs : Dict[str, nx.Graph]
        A dictionary where keys are layer names and values are NetworkX graphs.
    title : str, optional
        The title of the plot.
    save_path : str, optional
        If provided, saves the plot to this file path.

    Raises
    ------
    ImportError
        If the 'upsetplot' library is not installed.
    """
    if up_plot is None:
        raise ImportError("The 'upsetplot' library is required. Install it via: pip install upsetplot")

    # 1. Optimize: Get the binary overlap matrix
    # Returns a DataFrame with MultiIndex ('multilink', 'node')
    # The 'multilink' index contains binary strings (e.g., '101', '110')
    multi_adj_unweighted, _ = compute_multiplex_from_graphs(graphs)

    if multi_adj_unweighted.empty:
        print(f"Skipping Upset Plot: No data found for {title}")
        return

    # 2. Extract active edge counts per multilink configuration
    # Sum the rows (axis 1) to get degree per node per multilink
    # Then sum by multilink level to get total degree sum for that configuration
    # Divide by 2 because in undirected graphs, every edge is counted twice (once per node)
    edge_counts = multi_adj_unweighted.sum(axis=1).groupby(level='multilink').sum() / 2
    
    # Filter out configurations with 0 edges
    edge_counts = edge_counts[edge_counts > 0]

    if edge_counts.empty:
        print(f"Skipping Upset Plot: No edges found for {title}")
        return

    # 3. Convert binary strings (e.g., '101') to UpsetPlot Series format
    # The layers in the binary string are sorted alphabetically by default in compute_multiplex_from_graphs
    layer_names = sorted(graphs.keys())
    
    data_dict = {}
    
    for binary_str, count in edge_counts.items():
        # Identify which layers are active in this binary string
        # e.g., '101' -> ['LayerA', 'LayerC']
        active_layers = [
            layer_names[i] 
            for i, char in enumerate(binary_str) 
            if char == '1'
        ]
        
        if active_layers:
            # Upsetplot accepts a Series indexed by tuples of categories
            data_dict[tuple(active_layers)] = int(count)
            
    if not data_dict:
        print(f"No overlapping edges found for {title}.")
        return

    # Create the Series expected by upsetplot
    upset_series = pd.Series(data_dict)

    # 4. Plot
    plt.figure(figsize=(10, 6))
    
    # Draw the plot
    up_plot(upset_series, subset_size='count', show_counts=True, sort_by='cardinality')
    
    plt.suptitle(title, fontsize=16, y=1.05) # Adjust title position to not overlap
    
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
        plt.close()
    else:
        plt.show()