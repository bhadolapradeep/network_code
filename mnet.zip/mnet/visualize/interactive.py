# mnet/visualize/interactive.py

import networkx as nx
import os
from typing import Optional, Dict

try:
    from pyvis.network import Network
except ImportError:
    Network = None

def plot_interactive_network(
    graph: nx.Graph, 
    filename: str, 
    notebook: bool = False,
    height: str = "750px",
    width: str = "100%",
    bgcolor: str = "#222222",
    font_color: str = "white",
    node_color_map: Optional[Dict[str, str]] = None
) -> None:
    """
    Generate an interactive HTML visualization of a network using Pyvis.

    Parameters
    ----------
    graph : nx.Graph
        The NetworkX graph to visualize.
    filename : str
        The output path for the HTML file (e.g., 'output/network.html').
    notebook : bool, optional
        Whether to render the graph inside a Jupyter notebook.
    height : str, optional
        Height of the canvas (default "750px").
    width : str, optional
        Width of the canvas (default "100%").
    bgcolor : str, optional
        Background color (default dark grey "#222222").
    font_color : str, optional
        Font color for labels (default "white").
    node_color_map : Dict[str, str], optional
        A dictionary mapping node IDs to hex color codes (e.g., {'AAPL': '#ff0000'}).
        If None, default Pyvis colors are used.
    """
    if Network is None:
        raise ImportError("The 'pyvis' library is required. Install it via: pip install pyvis")

    # Ensure output directory exists
    os.makedirs(os.path.dirname(os.path.abspath(filename)), exist_ok=True)

    # Initialize Pyvis Network
    net = Network(height=height, width=width, bgcolor=bgcolor, font_color=font_color, notebook=notebook)
    
    # 1. ADD NODES with Color Logic
    for node, attributes in graph.nodes(data=True):
        # Create a copy of attributes so we don't mutate the original graph
        vis_attrs = attributes.copy()
        vis_attrs['label'] = str(node)
        vis_attrs['title'] = str(node) # Tooltip on hover

        # Apply Color Map if provided
        if node_color_map:
            # Use the map color if node exists in map, otherwise default to a neutral color
            vis_attrs['color'] = node_color_map.get(node, "#97C2FC")
        
        # If no map is provided, Pyvis uses the 'color' attribute in vis_attrs 
        # if it exists, otherwise it uses its default blue.

        net.add_node(node, **vis_attrs)

    # 2. ADD EDGES
    for source, target, data in graph.edges(data=True):
        net.add_edge(source, target, **data)

    # 3. SET PHYSICS (Optimized for financial networks)
    # Barnes-Hut is good for stabilizing large networks
    net.barnes_hut(gravity=-8000, central_gravity=0.3, spring_length=250)
    
    # Save
    net.save_graph(filename)
    return filename