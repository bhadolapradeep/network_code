# multinetlib/comparison/comparator.py

import pandas as pd
import networkx as nx
from typing import Dict, List, Any

class Comparator:
    """Compares properties across multiple single-layer networks.

    This class provides a convenient interface to compute and compare global
    and node-level properties for a collection of networks, returning the
    results in structured pandas DataFrames.

    Parameters
    ----------
    graphs : Dict[str, nx.Graph]
        A dictionary where keys are layer names and values are the
        corresponding NetworkX graphs to be compared.

    Attributes
    ----------
    networks : Dict[str, nx.Graph]
        The dictionary of networks provided at initialization.
    results : Dict[str, pd.DataFrame]
        A dictionary to store the results of comparison analyses.
    """
    def __init__(self, graphs: Dict[str, nx.Graph]):
        if not graphs or not isinstance(graphs, dict):
            raise ValueError("Input must be a non-empty dictionary of NetworkX graphs.")
        self.networks = graphs
        self.results: Dict[str, Any] = {}

    def compare_network_properties(self) -> pd.DataFrame:
        """Compute and compare global properties for each network.

        Calculates a standard set of global metrics for every network in the
        collection and aggregates them into a single DataFrame for easy
-       comparison.

        Returns
        -------
        pd.DataFrame
            A DataFrame where each row corresponds to a network (layer) and
            columns represent the calculated global properties.
        """
        props_list = []
        for name, G in self.networks.items():
            props = {'layer': name}
            if G.number_of_nodes() > 0:
                props.update({
                    'nodes': G.number_of_nodes(),
                    'edges': G.number_of_edges(),
                    'density': nx.density(G),
                    'avg_clustering': nx.average_clustering(G)
                })
                if nx.is_connected(G):
                    lcc = G
                else:
                    lcc_nodes = max(nx.connected_components(G), key=len, default=set())
                    lcc = G.subgraph(lcc_nodes) if lcc_nodes else G
                
                if lcc.number_of_nodes() > 1:
                     props['avg_path_length'] = nx.average_shortest_path_length(lcc)
                else:
                     props['avg_path_length'] = 0
            props_list.append(props)
            
        results_df = pd.DataFrame(props_list).set_index('layer')
        self.results['network_properties'] = results_df
        return results_df

    def compare_node_properties(self, properties: List[str] = ['degree_centrality', 'betweenness_centrality']) -> pd.DataFrame:
        """Compute and compare node-level properties across all layers.

        Parameters
        ----------
        properties : List[str], optional
            A list of node properties to compute. Supported values include
            'degree_centrality', 'betweenness_centrality', etc.
            Defaults to ['degree_centrality', 'betweenness_centrality'].

        Returns
        -------
        pd.DataFrame
            A tidy DataFrame with columns for 'layer', 'node', and each of
            the requested properties.
        """
        all_node_results = []
        prop_func_map = {
            'degree_centrality': nx.degree_centrality,
            'betweenness_centrality': nx.betweenness_centrality,
            'closeness_centrality': nx.closeness_centrality,
        }

        for name, G in self.networks.items():
            if G.number_of_nodes() == 0:
                continue
            
            layer_data = {'node': list(G.nodes())}
            for prop in properties:
                if prop in prop_func_map:
                    layer_data[prop] = list(prop_func_map[prop](G).values())

            layer_df = pd.DataFrame(layer_data)
            layer_df['layer'] = name
            all_node_results.append(layer_df)
            
        if not all_node_results:
             return pd.DataFrame()
             
        results_df = pd.concat(all_node_results, ignore_index=True)
        self.results['node_properties'] = results_df
        return results_df