# multinetlib/workflow/system_analyzer.py

import pandas as pd
import warnings
from typing import Dict, Any, Union
import networkx as nx

from ..network import construct
from ..multiplex import multilink_matrix

class SystemAnalyzer:
    """A class to manage and execute a full network analysis workflow.

    This class acts as a high-level controller that takes raw data (either
    time series or pre-computed adjacency matrices) and orchestrates the
    process of network construction and analysis.

    Parameters
    ----------
    data : Union[pd.DataFrame, Dict[str, pd.DataFrame]]
        Input data. Can be a single DataFrame for one layer or a dictionary
        of DataFrames for multiple layers.
    data_type : str, optional
        The nature of the input data. Must be one of 'timeseries' or
        'adjacency', by default 'timeseries'.
    """
    def __init__(self, data: Union[pd.DataFrame, Dict[str, pd.DataFrame]], data_type: str = 'timeseries'):
        if data_type not in ['timeseries', 'adjacency']:
            raise ValueError("data_type must be either 'timeseries' or 'adjacency'")
        self.raw_data = data
        self.data_type = data_type
        self.correlation_matrices: Dict[str, pd.DataFrame] = {}
        self.networks: Dict[str, nx.Graph] = {}
        self.results: Dict[str, Any] = {}

    def build_networks(self, threshold: float) -> None:
        """Build networks from the raw data using a specified threshold.

        If the data type is 'timeseries', it first computes correlation
        matrices. Then, it constructs networks using a threshold filter.

        Parameters
        ----------
        threshold : float
            The absolute correlation value to use for edge creation.
        """
        print(f"Building networks with threshold: {threshold:.2f}")
        data_dict = self.raw_data if isinstance(self.raw_data, dict) else {'layer1': self.raw_data}

        for name, df in data_dict.items():
            if self.data_type == 'timeseries':
                corr_matrix = df.corr(numeric_only=True)
                self.correlation_matrices[name] = corr_matrix
                self.networks[name] = construct.build_threshold_network(corr_matrix, threshold)
            elif self.data_type == 'adjacency':
                self.networks[name] = construct.build_threshold_network(df, threshold)
        print("...Done.")

    def analyze_multiplex_properties(self) -> None:
        """Perform core multiplex structure and property analysis."""
        if len(self.networks) < 2:
            warnings.warn("Multiplex analysis requires at least two layers. Skipping.")
            return

        print("Analyzing multiplex structure...")
        unweighted_multi_adj, weighted_multi_adj = multilink_matrix.compute_multiplex_from_graphs(self.networks)
        self.results['multiplex_analysis'] = {
            'unweighted_multi_adjacency': unweighted_multi_adj,
            'weighted_multi_adjacency': weighted_multi_adj,
        }
        print("...Done.")

    def run_full_analysis(self, threshold: float):
        """Execute the entire analysis pipeline.

        This convenience method runs the network construction and multiplex
        analysis steps in sequence.

        Parameters
        ----------
        threshold : float
            The correlation threshold to use for the entire analysis.
        """
        print("--- Starting Full Analysis Workflow ---")
        self.build_networks(threshold)
        self.analyze_multiplex_properties()
        print("--- Full Analysis Complete ---")

    def get_results(self, analysis_key: str) -> Any:
        """Retrieve results from a specific analysis step.

        Parameters
        ----------
        analysis_key : str
            The key for the desired results (e.g., 'multiplex_analysis').

        Returns
        -------
        Any
            The stored results, or None if the key is not found.
        """
        return self.results.get(analysis_key)