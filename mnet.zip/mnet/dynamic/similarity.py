# multinetlib/dynamic/similarity.py

import networkx as nx
from scipy.stats import pearsonr
import numpy as np

def calculate_network_similarity(graph1: nx.Graph, graph2: nx.Graph, method: str = 'degree_correlation') -> float:
    """Calculate the structural similarity between two networks.

    This function quantifies how similar two networks are based on a specified
    topological property.

    Parameters
    ----------
    graph1 : nx.Graph
        The first NetworkX graph.
    graph2 : nx.Graph
        The second NetworkX graph.
    method : str, optional
        The method for calculating similarity. Currently supports:
        - 'degree_correlation' (default): Computes the Pearson correlation
          coefficient between the degree centrality vectors of the two graphs.

    Returns
    -------
    float
        A similarity score, typically between -1.0 and 1.0 for correlation-based
        methods. Returns NaN if similarity cannot be computed.

    Raises
    ------
    ValueError
        If an unsupported similarity method is specified.
    """
    if method == 'degree_correlation':
        # Get the union of all nodes to create comparable vectors
        all_nodes = sorted(list(set(graph1.nodes()) | set(graph2.nodes())))
        if not all_nodes:
            return 1.0 # Two empty graphs are perfectly similar

        c1 = nx.degree_centrality(graph1)
        c2 = nx.degree_centrality(graph2)
        
        # Create vectors where missing nodes have a centrality of 0
        vec1 = np.array([c1.get(node, 0) for node in all_nodes])
        vec2 = np.array([c2.get(node, 0) for node in all_nodes])

        # Correlation is undefined if one vector has zero variance
        if np.std(vec1) == 0 or np.std(vec2) == 0:
            return np.nan
            
        correlation, _ = pearsonr(vec1, vec2)
        return correlation
    else:
        raise ValueError(f"Unsupported similarity method: {method}")